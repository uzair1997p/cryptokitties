import { Link } from 'react-router-dom'
// import { Navbar, Nav, NavItem } from 'react-bootstrap'
import './NavBar.css'
import { Navbar, Nav, NavDropdown, Button } from 'react-bootstrap'
const NavBar = () => {
    return (
        <div  >
            <Navbar bg="white" expand="lg" className="py-4" style={{ fontSize: '17px', fontWeight: "500" }}>

                <Navbar.Brand href="/" className="pl-4">
                    <img src="https://www.cryptokitties.co/icons/logo.svg" alt="Logo" />
                    <span>CryptoKitties
                    </span>
                </Navbar.Brand>
                <Navbar.Toggle aria-controls="basic-navbar-nav" />
                <Navbar.Collapse id="basic-navbar-nav">
                    <Nav className="ml-auto ">
                        <NavDropdown title={`Catalogue`} href="#">

                            <NavDropdown.Item className="px-5">
                                <Link to="/">
                                    Catalogue</Link>

                            </NavDropdown.Item >
                        </NavDropdown>
                        <Nav.Link className="px-5">
                            <Link to="/blog">
                                Search
                            </Link>

                        </Nav.Link>
                        <Nav.Link className="px-5">
                            <Link to="/blog">
                                Guides
                            </Link>

                        </Nav.Link>
                        <NavDropdown className="px-5" title="More" id="basic-nav-dropdown" renderMenuOnMount={true}>
                            <NavDropdown.Item >
                                <Link to="/blog">
                                    Blog
                                </Link>
                            </NavDropdown.Item>
                            <NavDropdown.Divider />
                            <NavDropdown.Item >
                                <Link to="/about">
                                    About
                                </Link>
                            </NavDropdown.Item>
                            <NavDropdown.Divider />
                            <NavDropdown.Item >
                                <Link to="/event">
                                    Event
                                </Link>
                            </NavDropdown.Item>
                            <NavDropdown.Divider />
                            <NavDropdown.Item >
                                <Link to="/news-letter">
                                    News Letter
                                </Link>
                            </NavDropdown.Item>
                            <NavDropdown.Divider />
                            <NavDropdown.Item >
                                <Link to="/kitty-verse">
                                    Kitty Verse
                                </Link>
                            </NavDropdown.Item>

                        </NavDropdown>
                        <Nav.Link  >
                            <Button className="px-4 py-3" style={{ backgroundColor: "hotpink!important" }} >Start</Button>
                            <span className="px-5">
                                <svg class="IconV2 IconV2--position-default IconV2--display-inlineBlock" width="16" height="16" viewBox="0 0 16 16"><path fill="none" fill-rule="evenodd" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.261" d="M8 14.5a6.5 6.5 0 1 0 0-13 6.5 6.5 0 0 0 0 13zm-1.43-1.849c.061-.061.123-.184.308-.337.736-.706-.676-.492-.062-1.167.492-.521.062-1.166-.307-1.381-.276-.185-.706.06-.86-.216-.276-.491-.4.4-.768.185m-.767.122c-.246.153-.4.337-.4.337m9.396-3.192s-1.198-.553-1.658.245c-.492.83-.737.614-1.535.768M8.35 4.607c.369.307.4.553.123.645-.736.215-.675 1.013-.337 1.013.337 0 .676 0 .337.337-.337.338-.184 2.027.676 1.658m-.368-5.403s-2.119.768-1.474 1.136c.184.092.338.185.46.277"></path></svg></span>
                        </Nav.Link>
                    </Nav>
                </Navbar.Collapse>

            </Navbar>
            <div >
                <span >



                </span>
            </div>



        </div >
    )
}

export default NavBar
