import { Container, Row, Col } from "react-bootstrap"

const Footer = () => {
    return (
        <div>
            {/* 

           
             */}
            <Container className="" fluid style={{

                borderColor:
                    "#f3f1ee",
                borderStyle:
                    "solid none none",
                borderWidth:
                    "2px 0px 0px",
                color:
                    "#2a2825",
                fontFamily:
                    "Calibre, sans-serif",
                fontSize:
                    "14px",
                lineHeight:
                    "28px",
            }} >
                <Row className="mx-5 px-5 mt-5">
                    <Col md={3}>
                        <p>My Profile
                        </p>
                        <p>Activity
                        </p>
                        <p>Search
                        </p>
                        <p>KittyVerse
                        </p>
                        <p>FAQs
                        </p>
                        <p>Player's Guide
                        </p>
                        <p>Email us</p>
                    </Col>
                    <Col md={3}>
                        <p>About</p>
                        <p>Press</p>
                        <p>Tech details</p>
                        <p>White Pa-purr</p>
                        <p>Our Newsletter</p>
                        <p>Cheeze Wizards</p>
                        <p>NBA Top Shot</p>
                        <p>Flow Blockchain</p>
                    </Col>
                    <Col md={3}>
                        <p>Facebook</p>
                        <p>Reddit</p>
                        <p>Twitter</p>
                        <p>YouTube</p>
                        <p>Instagram</p>
                        <p>Discord</p>
                        <p>Twitch</p>
                    </Col>
                    <Col md={3}>
                        <p>Pick of the litter at Dapper Labs Purrrrr</p>
                        <p>View our job openings</p>
                    </Col>
                    <Col md={12} >
                        <div className="d-flex justify-content-center">

                            <span>
                                term of use

                            </span>
                            <span className="ml-5">
                                Privacy Policy
                            </span>
                        </div>
                    </Col>
                </Row>
            </Container>
          

        </div>
    )
}

export default Footer
