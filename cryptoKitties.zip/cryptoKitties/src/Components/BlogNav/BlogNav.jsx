
import { Navbar, Nav, NavDropdown, Button, Container, Row, Col, Card } from 'react-bootstrap'
import './Blog.css'
const BlogNav = () => {
    return (
        <div>
            <Navbar bg="white" expand="lg">

                <Navbar.Brand href="#home"> <img src="https://www.cryptokitties.co/icons/logo.svg" alt="Logo" />
                    <span>CryptoKitties
                    </span></Navbar.Brand>
                <Navbar.Toggle aria-controls="basic-navbar-nav" />
                <Navbar.Collapse id="basic-navbar-nav">
                    <Nav className="ml-auto">
                        <Nav.Link href="">
                            <Button size="lg">
                                Play CryptoKitties
                            </Button>
                        </Nav.Link>

                    </Nav>
                </Navbar.Collapse>

            </Navbar>


            <Container className="mt-5">
                <Row>
                    <Col md={6}>
                        <Card >
                            <Card.Img variant="top" src="https://images.ctfassets.net/bktrgw6io7fv/53IF2ekYV59voLrWbYN1g4/bcc8c918a743b45d124aa528921ffc5b/Fancy-variant.png?w=904&h=494&q=50&fm=webp&fit=fill" />
                            <Card.Body>
                                <Card.Title>Introducing:Fancy Variant Badges</Card.Title>
                                <Card.Text>
                                    Not All Fancies Are the Same
                                </Card.Text>
                                <Card.Text>
                                    dec 19
                                </Card.Text>
                            </Card.Body>
                        </Card>
                    </Col>
                    <Col md={6}>
                        <Card >
                            <Card.Img variant="top" src="https://images.ctfassets.net/bktrgw6io7fv/53IF2ekYV59voLrWbYN1g4/bcc8c918a743b45d124aa528921ffc5b/Fancy-variant.png?w=904&h=494&q=50&fm=webp&fit=fill" />
                            <Card.Body>
                                <Card.Title>Introducing:Fancy Variant Badges</Card.Title>
                                <Card.Text>
                                    Not All Fancies Are the Same
                                </Card.Text>
                                <Card.Text>
                                    dec 19
                                </Card.Text>
                            </Card.Body>
                        </Card>
                    </Col>
                    <Col md={6}>
                        <Card >
                            <Card.Img variant="top" src="https://images.ctfassets.net/bktrgw6io7fv/53IF2ekYV59voLrWbYN1g4/bcc8c918a743b45d124aa528921ffc5b/Fancy-variant.png?w=904&h=494&q=50&fm=webp&fit=fill" />
                            <Card.Body>
                                <Card.Title>Introducing:Fancy Variant Badges</Card.Title>
                                <Card.Text>
                                    Not All Fancies Are the Same
                                </Card.Text>
                                <Card.Text>
                                    dec 19
                                </Card.Text>
                            </Card.Body>
                        </Card>
                    </Col>
                    <Col md={6}>
                        <Card >
                            <Card.Img variant="top" src="https://images.ctfassets.net/bktrgw6io7fv/53IF2ekYV59voLrWbYN1g4/bcc8c918a743b45d124aa528921ffc5b/Fancy-variant.png?w=904&h=494&q=50&fm=webp&fit=fill" />
                            <Card.Body>
                                <Card.Title>Introducing:Fancy Variant Badges</Card.Title>
                                <Card.Text>
                                    Not All Fancies Are the Same
                                </Card.Text>
                                <Card.Text>
                                    dec 19
                                </Card.Text>
                            </Card.Body>
                        </Card>
                    </Col>
                    <Col md={6}>
                        <Card >
                            <Card.Img variant="top" src="https://images.ctfassets.net/bktrgw6io7fv/53IF2ekYV59voLrWbYN1g4/bcc8c918a743b45d124aa528921ffc5b/Fancy-variant.png?w=904&h=494&q=50&fm=webp&fit=fill" />
                            <Card.Body>
                                <Card.Title>Introducing:Fancy Variant Badges</Card.Title>
                                <Card.Text>
                                    Not All Fancies Are the Same
                                </Card.Text>
                                <Card.Text>
                                    dec 19
                                </Card.Text>
                            </Card.Body>
                        </Card>
                    </Col>
                    <Col md={6}>
                        <Card >
                            <Card.Img variant="top" src="https://images.ctfassets.net/bktrgw6io7fv/53IF2ekYV59voLrWbYN1g4/bcc8c918a743b45d124aa528921ffc5b/Fancy-variant.png?w=904&h=494&q=50&fm=webp&fit=fill" />
                            <Card.Body>
                                <Card.Title>Introducing:Fancy Variant Badges</Card.Title>
                                <Card.Text>
                                    Not All Fancies Are the Same
                                </Card.Text>
                                <Card.Text>
                                    dec 19
                                </Card.Text>
                            </Card.Body>
                        </Card>
                    </Col>
                    <Col md={6}>
                        <Card >
                            <Card.Img variant="top" src="https://images.ctfassets.net/bktrgw6io7fv/53IF2ekYV59voLrWbYN1g4/bcc8c918a743b45d124aa528921ffc5b/Fancy-variant.png?w=904&h=494&q=50&fm=webp&fit=fill" />
                            <Card.Body>
                                <Card.Title>Introducing:Fancy Variant Badges</Card.Title>
                                <Card.Text>
                                    Not All Fancies Are the Same
                                </Card.Text>
                                <Card.Text>
                                    dec 19
                                </Card.Text>
                            </Card.Body>
                        </Card>
                    </Col>
                    <Col md={6}>
                        <Card >
                            <Card.Img variant="top" src="https://images.ctfassets.net/bktrgw6io7fv/53IF2ekYV59voLrWbYN1g4/bcc8c918a743b45d124aa528921ffc5b/Fancy-variant.png?w=904&h=494&q=50&fm=webp&fit=fill" />
                            <Card.Body>
                                <Card.Title>Introducing:Fancy Variant Badges</Card.Title>
                                <Card.Text>
                                    Not All Fancies Are the Same
                                </Card.Text>
                                <Card.Text>
                                    dec 19
                                </Card.Text>
                            </Card.Body>
                        </Card>
                    </Col>
                </Row>
            </Container>
            <Container>
                <Row>
                    <Col md={3}>
                        <div class="PopularTopic-main"><div class=" gatsby-image-wrapper" style={{ position: "relative", overflow: "hidden" }}><div aria-hidden="true" style={{ width: "100%", paddingBottom: "87.7358%" }}></div><picture><source type="image/webp" srcset="//images.ctfassets.net/bktrgw6io7fv/4KdAATp7HWm0mGUGGicMok/e642bd03ca93f52c878a17233d042951/ck-updates.jpeg?w=106&amp;h=93&amp;q=50&amp;fm=webp&amp;fit=fill 106w,
                    //images.ctfassets.net/bktrgw6io7fv/4KdAATp7HWm0mGUGGicMok/e642bd03ca93f52c878a17233d042951/ck-updates.jpeg?w=212&amp;h=186&amp;q=50&amp;fm=webp&amp;fit=fill 212w,
                    //images.ctfassets.net/bktrgw6io7fv/4KdAATp7HWm0mGUGGicMok/e642bd03ca93f52c878a17233d042951/ck-updates.jpeg?w=424&amp;h=372&amp;q=50&amp;fm=webp&amp;fit=fill 424w,
                    //images.ctfassets.net/bktrgw6io7fv/4KdAATp7HWm0mGUGGicMok/e642bd03ca93f52c878a17233d042951/ck-updates.jpeg?w=636&amp;h=558&amp;q=50&amp;fm=webp&amp;fit=fill 636w,
                    //images.ctfassets.net/bktrgw6io7fv/4KdAATp7HWm0mGUGGicMok/e642bd03ca93f52c878a17233d042951/ck-updates.jpeg?w=848&amp;h=744&amp;q=50&amp;fm=webp&amp;fit=fill 848w,
                    //images.ctfassets.net/bktrgw6io7fv/4KdAATp7HWm0mGUGGicMok/e642bd03ca93f52c878a17233d042951/ck-updates.jpeg?w=1272&amp;h=1116&amp;q=50&amp;fm=webp&amp;fit=fill 1272w,
                    //images.ctfassets.net/bktrgw6io7fv/4KdAATp7HWm0mGUGGicMok/e642bd03ca93f52c878a17233d042951/ck-updates.jpeg?w=2000&amp;h=1755&amp;q=50&amp;fm=webp&amp;fit=fill 2000w" sizes="(max-width: 424px) 100vw, 424px" /><source srcset="//images.ctfassets.net/bktrgw6io7fv/4KdAATp7HWm0mGUGGicMok/e642bd03ca93f52c878a17233d042951/ck-updates.jpeg?w=106&amp;h=93&amp;q=50&amp;fit=fill 106w,
                    //images.ctfassets.net/bktrgw6io7fv/4KdAATp7HWm0mGUGGicMok/e642bd03ca93f52c878a17233d042951/ck-updates.jpeg?w=212&amp;h=186&amp;q=50&amp;fit=fill 212w,
                    //images.ctfassets.net/bktrgw6io7fv/4KdAATp7HWm0mGUGGicMok/e642bd03ca93f52c878a17233d042951/ck-updates.jpeg?w=424&amp;h=372&amp;q=50&amp;fit=fill 424w,
                    //images.ctfassets.net/bktrgw6io7fv/4KdAATp7HWm0mGUGGicMok/e642bd03ca93f52c878a17233d042951/ck-updates.jpeg?w=636&amp;h=558&amp;q=50&amp;fit=fill 636w,
                    //images.ctfassets.net/bktrgw6io7fv/4KdAATp7HWm0mGUGGicMok/e642bd03ca93f52c878a17233d042951/ck-updates.jpeg?w=848&amp;h=744&amp;q=50&amp;fit=fill 848w,
                    //images.ctfassets.net/bktrgw6io7fv/4KdAATp7HWm0mGUGGicMok/e642bd03ca93f52c878a17233d042951/ck-updates.jpeg?w=1272&amp;h=1116&amp;q=50&amp;fit=fill 1272w,
                    //images.ctfassets.net/bktrgw6io7fv/4KdAATp7HWm0mGUGGicMok/e642bd03ca93f52c878a17233d042951/ck-updates.jpeg?w=2000&amp;h=1755&amp;q=50&amp;fit=fill 2000w" sizes="(max-width: 424px) 100vw, 424px" /><img sizes="(max-width: 424px) 100vw, 424px" srcset="//images.ctfassets.net/bktrgw6io7fv/4KdAATp7HWm0mGUGGicMok/e642bd03ca93f52c878a17233d042951/ck-updates.jpeg?w=106&amp;h=93&amp;q=50&amp;fit=fill 106w,
                    //images.ctfassets.net/bktrgw6io7fv/4KdAATp7HWm0mGUGGicMok/e642bd03ca93f52c878a17233d042951/ck-updates.jpeg?w=212&amp;h=186&amp;q=50&amp;fit=fill 212w,
                    //images.ctfassets.net/bktrgw6io7fv/4KdAATp7HWm0mGUGGicMok/e642bd03ca93f52c878a17233d042951/ck-updates.jpeg?w=424&amp;h=372&amp;q=50&amp;fit=fill 424w,
                    //images.ctfassets.net/bktrgw6io7fv/4KdAATp7HWm0mGUGGicMok/e642bd03ca93f52c878a17233d042951/ck-updates.jpeg?w=636&amp;h=558&amp;q=50&amp;fit=fill 636w,
                    //images.ctfassets.net/bktrgw6io7fv/4KdAATp7HWm0mGUGGicMok/e642bd03ca93f52c878a17233d042951/ck-updates.jpeg?w=848&amp;h=744&amp;q=50&amp;fit=fill 848w,
                    //images.ctfassets.net/bktrgw6io7fv/4KdAATp7HWm0mGUGGicMok/e642bd03ca93f52c878a17233d042951/ck-updates.jpeg?w=1272&amp;h=1116&amp;q=50&amp;fit=fill 1272w,
                    //images.ctfassets.net/bktrgw6io7fv/4KdAATp7HWm0mGUGGicMok/e642bd03ca93f52c878a17233d042951/ck-updates.jpeg?w=2000&amp;h=1755&amp;q=50&amp;fit=fill 2000w" src="//images.ctfassets.net/bktrgw6io7fv/4KdAATp7HWm0mGUGGicMok/e642bd03ca93f52c878a17233d042951/ck-updates.jpeg?w=424&amp;h=372&amp;q=50&amp;fit=fill" alt="How To image" loading="lazy" style={{ position: "absolute", top: "0px", left: "0px", width: "100%", height: "100%", objectFit: "cover", objectPosition: "center center", opacity: 1, transition: "none 0s ease 0s" }} /></picture><noscript><picture><source type='image/webp' srcset="//images.ctfassets.net/bktrgw6io7fv/4KdAATp7HWm0mGUGGicMok/e642bd03ca93f52c878a17233d042951/ck-updates.jpeg?w=106&h=93&q=50&fm=webp&fit=fill 106w,
                    //images.ctfassets.net/bktrgw6io7fv/4KdAATp7HWm0mGUGGicMok/e642bd03ca93f52c878a17233d042951/ck-updates.jpeg?w=212&h=186&q=50&fm=webp&fit=fill 212w,
                    //images.ctfassets.net/bktrgw6io7fv/4KdAATp7HWm0mGUGGicMok/e642bd03ca93f52c878a17233d042951/ck-updates.jpeg?w=424&h=372&q=50&fm=webp&fit=fill 424w,
                    //images.ctfassets.net/bktrgw6io7fv/4KdAATp7HWm0mGUGGicMok/e642bd03ca93f52c878a17233d042951/ck-updates.jpeg?w=636&h=558&q=50&fm=webp&fit=fill 636w,
                    //images.ctfassets.net/bktrgw6io7fv/4KdAATp7HWm0mGUGGicMok/e642bd03ca93f52c878a17233d042951/ck-updates.jpeg?w=848&h=744&q=50&fm=webp&fit=fill 848w,
                    //images.ctfassets.net/bktrgw6io7fv/4KdAATp7HWm0mGUGGicMok/e642bd03ca93f52c878a17233d042951/ck-updates.jpeg?w=1272&h=1116&q=50&fm=webp&fit=fill 1272w,
                    //images.ctfassets.net/bktrgw6io7fv/4KdAATp7HWm0mGUGGicMok/e642bd03ca93f52c878a17233d042951/ck-updates.jpeg?w=2000&h=1755&q=50&fm=webp&fit=fill 2000w" sizes="(max-width: 424px) 100vw, 424px" /><source srcset="//images.ctfassets.net/bktrgw6io7fv/4KdAATp7HWm0mGUGGicMok/e642bd03ca93f52c878a17233d042951/ck-updates.jpeg?w=106&h=93&q=50&fit=fill 106w,
                    //images.ctfassets.net/bktrgw6io7fv/4KdAATp7HWm0mGUGGicMok/e642bd03ca93f52c878a17233d042951/ck-updates.jpeg?w=212&h=186&q=50&fit=fill 212w,
                    //images.ctfassets.net/bktrgw6io7fv/4KdAATp7HWm0mGUGGicMok/e642bd03ca93f52c878a17233d042951/ck-updates.jpeg?w=424&h=372&q=50&fit=fill 424w,
                    //images.ctfassets.net/bktrgw6io7fv/4KdAATp7HWm0mGUGGicMok/e642bd03ca93f52c878a17233d042951/ck-updates.jpeg?w=636&h=558&q=50&fit=fill 636w,
                    //images.ctfassets.net/bktrgw6io7fv/4KdAATp7HWm0mGUGGicMok/e642bd03ca93f52c878a17233d042951/ck-updates.jpeg?w=848&h=744&q=50&fit=fill 848w,
                    //images.ctfassets.net/bktrgw6io7fv/4KdAATp7HWm0mGUGGicMok/e642bd03ca93f52c878a17233d042951/ck-updates.jpeg?w=1272&h=1116&q=50&fit=fill 1272w,
                    //images.ctfassets.net/bktrgw6io7fv/4KdAATp7HWm0mGUGGicMok/e642bd03ca93f52c878a17233d042951/ck-updates.jpeg?w=2000&h=1755&q=50&fit=fill 2000w" sizes="(max-width: 424px) 100vw, 424px" /><img loading="lazy" sizes="(max-width: 424px) 100vw, 424px" srcset="//images.ctfassets.net/bktrgw6io7fv/4KdAATp7HWm0mGUGGicMok/e642bd03ca93f52c878a17233d042951/ck-updates.jpeg?w=106&h=93&q=50&fit=fill 106w,
                    //images.ctfassets.net/bktrgw6io7fv/4KdAATp7HWm0mGUGGicMok/e642bd03ca93f52c878a17233d042951/ck-updates.jpeg?w=212&h=186&q=50&fit=fill 212w,
                    //images.ctfassets.net/bktrgw6io7fv/4KdAATp7HWm0mGUGGicMok/e642bd03ca93f52c878a17233d042951/ck-updates.jpeg?w=424&h=372&q=50&fit=fill 424w,
                    //images.ctfassets.net/bktrgw6io7fv/4KdAATp7HWm0mGUGGicMok/e642bd03ca93f52c878a17233d042951/ck-updates.jpeg?w=636&h=558&q=50&fit=fill 636w,
                    //images.ctfassets.net/bktrgw6io7fv/4KdAATp7HWm0mGUGGicMok/e642bd03ca93f52c878a17233d042951/ck-updates.jpeg?w=848&h=744&q=50&fit=fill 848w,
                    //images.ctfassets.net/bktrgw6io7fv/4KdAATp7HWm0mGUGGicMok/e642bd03ca93f52c878a17233d042951/ck-updates.jpeg?w=1272&h=1116&q=50&fit=fill 1272w,
                    //images.ctfassets.net/bktrgw6io7fv/4KdAATp7HWm0mGUGGicMok/e642bd03ca93f52c878a17233d042951/ck-updates.jpeg?w=2000&h=1755&q=50&fit=fill 2000w" src="//images.ctfassets.net/bktrgw6io7fv/4KdAATp7HWm0mGUGGicMok/e642bd03ca93f52c878a17233d042951/ck-updates.jpeg?w=424&h=372&q=50&fit=fill" alt="How To image" style={{ position: "absolute", top: 0, left: 0, opacity: 1, width: "100 % ", height: "100% ", objectFit: "cover", objectPosition: "center" }} /></picture></noscript></div><div class="PopularTopic-icon"><img src="//images.ctfassets.net/bktrgw6io7fv/63TmRtAd68W0aa8msaG22o/a1dcbf563da65b979f78a01db929285e/logo.svg" alt="How To icon" /></div><h2 class="PopularTopic-title">How To</h2></div>
                    </Col>
                    <Col md={3}>
                        <div class="PopularTopic-main"><div class=" gatsby-image-wrapper" style={{ position: "relative", overflow: "hidden" }}><div aria-hidden="true" style={{ width: "100%", paddingBottom: "87.7358%" }}></div><picture><source type="image/webp" srcset="//images.ctfassets.net/bktrgw6io7fv/4KdAATp7HWm0mGUGGicMok/e642bd03ca93f52c878a17233d042951/ck-updates.jpeg?w=106&amp;h=93&amp;q=50&amp;fm=webp&amp;fit=fill 106w,
                    //images.ctfassets.net/bktrgw6io7fv/4KdAATp7HWm0mGUGGicMok/e642bd03ca93f52c878a17233d042951/ck-updates.jpeg?w=212&amp;h=186&amp;q=50&amp;fm=webp&amp;fit=fill 212w,
                    //images.ctfassets.net/bktrgw6io7fv/4KdAATp7HWm0mGUGGicMok/e642bd03ca93f52c878a17233d042951/ck-updates.jpeg?w=424&amp;h=372&amp;q=50&amp;fm=webp&amp;fit=fill 424w,
                    //images.ctfassets.net/bktrgw6io7fv/4KdAATp7HWm0mGUGGicMok/e642bd03ca93f52c878a17233d042951/ck-updates.jpeg?w=636&amp;h=558&amp;q=50&amp;fm=webp&amp;fit=fill 636w,
                    //images.ctfassets.net/bktrgw6io7fv/4KdAATp7HWm0mGUGGicMok/e642bd03ca93f52c878a17233d042951/ck-updates.jpeg?w=848&amp;h=744&amp;q=50&amp;fm=webp&amp;fit=fill 848w,
                    //images.ctfassets.net/bktrgw6io7fv/4KdAATp7HWm0mGUGGicMok/e642bd03ca93f52c878a17233d042951/ck-updates.jpeg?w=1272&amp;h=1116&amp;q=50&amp;fm=webp&amp;fit=fill 1272w,
                    //images.ctfassets.net/bktrgw6io7fv/4KdAATp7HWm0mGUGGicMok/e642bd03ca93f52c878a17233d042951/ck-updates.jpeg?w=2000&amp;h=1755&amp;q=50&amp;fm=webp&amp;fit=fill 2000w" sizes="(max-width: 424px) 100vw, 424px" /><source srcset="//images.ctfassets.net/bktrgw6io7fv/4KdAATp7HWm0mGUGGicMok/e642bd03ca93f52c878a17233d042951/ck-updates.jpeg?w=106&amp;h=93&amp;q=50&amp;fit=fill 106w,
                    //images.ctfassets.net/bktrgw6io7fv/4KdAATp7HWm0mGUGGicMok/e642bd03ca93f52c878a17233d042951/ck-updates.jpeg?w=212&amp;h=186&amp;q=50&amp;fit=fill 212w,
                    //images.ctfassets.net/bktrgw6io7fv/4KdAATp7HWm0mGUGGicMok/e642bd03ca93f52c878a17233d042951/ck-updates.jpeg?w=424&amp;h=372&amp;q=50&amp;fit=fill 424w,
                    //images.ctfassets.net/bktrgw6io7fv/4KdAATp7HWm0mGUGGicMok/e642bd03ca93f52c878a17233d042951/ck-updates.jpeg?w=636&amp;h=558&amp;q=50&amp;fit=fill 636w,
                    //images.ctfassets.net/bktrgw6io7fv/4KdAATp7HWm0mGUGGicMok/e642bd03ca93f52c878a17233d042951/ck-updates.jpeg?w=848&amp;h=744&amp;q=50&amp;fit=fill 848w,
                    //images.ctfassets.net/bktrgw6io7fv/4KdAATp7HWm0mGUGGicMok/e642bd03ca93f52c878a17233d042951/ck-updates.jpeg?w=1272&amp;h=1116&amp;q=50&amp;fit=fill 1272w,
                    //images.ctfassets.net/bktrgw6io7fv/4KdAATp7HWm0mGUGGicMok/e642bd03ca93f52c878a17233d042951/ck-updates.jpeg?w=2000&amp;h=1755&amp;q=50&amp;fit=fill 2000w" sizes="(max-width: 424px) 100vw, 424px" /><img sizes="(max-width: 424px) 100vw, 424px" srcset="//images.ctfassets.net/bktrgw6io7fv/4KdAATp7HWm0mGUGGicMok/e642bd03ca93f52c878a17233d042951/ck-updates.jpeg?w=106&amp;h=93&amp;q=50&amp;fit=fill 106w,
                    //images.ctfassets.net/bktrgw6io7fv/4KdAATp7HWm0mGUGGicMok/e642bd03ca93f52c878a17233d042951/ck-updates.jpeg?w=212&amp;h=186&amp;q=50&amp;fit=fill 212w,
                    //images.ctfassets.net/bktrgw6io7fv/4KdAATp7HWm0mGUGGicMok/e642bd03ca93f52c878a17233d042951/ck-updates.jpeg?w=424&amp;h=372&amp;q=50&amp;fit=fill 424w,
                    //images.ctfassets.net/bktrgw6io7fv/4KdAATp7HWm0mGUGGicMok/e642bd03ca93f52c878a17233d042951/ck-updates.jpeg?w=636&amp;h=558&amp;q=50&amp;fit=fill 636w,
                    //images.ctfassets.net/bktrgw6io7fv/4KdAATp7HWm0mGUGGicMok/e642bd03ca93f52c878a17233d042951/ck-updates.jpeg?w=848&amp;h=744&amp;q=50&amp;fit=fill 848w,
                    //images.ctfassets.net/bktrgw6io7fv/4KdAATp7HWm0mGUGGicMok/e642bd03ca93f52c878a17233d042951/ck-updates.jpeg?w=1272&amp;h=1116&amp;q=50&amp;fit=fill 1272w,
                    //images.ctfassets.net/bktrgw6io7fv/4KdAATp7HWm0mGUGGicMok/e642bd03ca93f52c878a17233d042951/ck-updates.jpeg?w=2000&amp;h=1755&amp;q=50&amp;fit=fill 2000w" src="//images.ctfassets.net/bktrgw6io7fv/4KdAATp7HWm0mGUGGicMok/e642bd03ca93f52c878a17233d042951/ck-updates.jpeg?w=424&amp;h=372&amp;q=50&amp;fit=fill" alt="How To image" loading="lazy" style={{ position: "absolute", top: "0px", left: "0px", width: "100%", height: "100%", objectFit: "cover", objectPosition: "center center", opacity: 1, transition: "none 0s ease 0s" }} /></picture><noscript><picture><source type='image/webp' srcset="//images.ctfassets.net/bktrgw6io7fv/4KdAATp7HWm0mGUGGicMok/e642bd03ca93f52c878a17233d042951/ck-updates.jpeg?w=106&h=93&q=50&fm=webp&fit=fill 106w,
                    //images.ctfassets.net/bktrgw6io7fv/4KdAATp7HWm0mGUGGicMok/e642bd03ca93f52c878a17233d042951/ck-updates.jpeg?w=212&h=186&q=50&fm=webp&fit=fill 212w,
                    //images.ctfassets.net/bktrgw6io7fv/4KdAATp7HWm0mGUGGicMok/e642bd03ca93f52c878a17233d042951/ck-updates.jpeg?w=424&h=372&q=50&fm=webp&fit=fill 424w,
                    //images.ctfassets.net/bktrgw6io7fv/4KdAATp7HWm0mGUGGicMok/e642bd03ca93f52c878a17233d042951/ck-updates.jpeg?w=636&h=558&q=50&fm=webp&fit=fill 636w,
                    //images.ctfassets.net/bktrgw6io7fv/4KdAATp7HWm0mGUGGicMok/e642bd03ca93f52c878a17233d042951/ck-updates.jpeg?w=848&h=744&q=50&fm=webp&fit=fill 848w,
                    //images.ctfassets.net/bktrgw6io7fv/4KdAATp7HWm0mGUGGicMok/e642bd03ca93f52c878a17233d042951/ck-updates.jpeg?w=1272&h=1116&q=50&fm=webp&fit=fill 1272w,
                    //images.ctfassets.net/bktrgw6io7fv/4KdAATp7HWm0mGUGGicMok/e642bd03ca93f52c878a17233d042951/ck-updates.jpeg?w=2000&h=1755&q=50&fm=webp&fit=fill 2000w" sizes="(max-width: 424px) 100vw, 424px" /><source srcset="//images.ctfassets.net/bktrgw6io7fv/4KdAATp7HWm0mGUGGicMok/e642bd03ca93f52c878a17233d042951/ck-updates.jpeg?w=106&h=93&q=50&fit=fill 106w,
                    //images.ctfassets.net/bktrgw6io7fv/4KdAATp7HWm0mGUGGicMok/e642bd03ca93f52c878a17233d042951/ck-updates.jpeg?w=212&h=186&q=50&fit=fill 212w,
                    //images.ctfassets.net/bktrgw6io7fv/4KdAATp7HWm0mGUGGicMok/e642bd03ca93f52c878a17233d042951/ck-updates.jpeg?w=424&h=372&q=50&fit=fill 424w,
                    //images.ctfassets.net/bktrgw6io7fv/4KdAATp7HWm0mGUGGicMok/e642bd03ca93f52c878a17233d042951/ck-updates.jpeg?w=636&h=558&q=50&fit=fill 636w,
                    //images.ctfassets.net/bktrgw6io7fv/4KdAATp7HWm0mGUGGicMok/e642bd03ca93f52c878a17233d042951/ck-updates.jpeg?w=848&h=744&q=50&fit=fill 848w,
                    //images.ctfassets.net/bktrgw6io7fv/4KdAATp7HWm0mGUGGicMok/e642bd03ca93f52c878a17233d042951/ck-updates.jpeg?w=1272&h=1116&q=50&fit=fill 1272w,
                    //images.ctfassets.net/bktrgw6io7fv/4KdAATp7HWm0mGUGGicMok/e642bd03ca93f52c878a17233d042951/ck-updates.jpeg?w=2000&h=1755&q=50&fit=fill 2000w" sizes="(max-width: 424px) 100vw, 424px" /><img loading="lazy" sizes="(max-width: 424px) 100vw, 424px" srcset="//images.ctfassets.net/bktrgw6io7fv/4KdAATp7HWm0mGUGGicMok/e642bd03ca93f52c878a17233d042951/ck-updates.jpeg?w=106&h=93&q=50&fit=fill 106w,
                    //images.ctfassets.net/bktrgw6io7fv/4KdAATp7HWm0mGUGGicMok/e642bd03ca93f52c878a17233d042951/ck-updates.jpeg?w=212&h=186&q=50&fit=fill 212w,
                    //images.ctfassets.net/bktrgw6io7fv/4KdAATp7HWm0mGUGGicMok/e642bd03ca93f52c878a17233d042951/ck-updates.jpeg?w=424&h=372&q=50&fit=fill 424w,
                    //images.ctfassets.net/bktrgw6io7fv/4KdAATp7HWm0mGUGGicMok/e642bd03ca93f52c878a17233d042951/ck-updates.jpeg?w=636&h=558&q=50&fit=fill 636w,
                    //images.ctfassets.net/bktrgw6io7fv/4KdAATp7HWm0mGUGGicMok/e642bd03ca93f52c878a17233d042951/ck-updates.jpeg?w=848&h=744&q=50&fit=fill 848w,
                    //images.ctfassets.net/bktrgw6io7fv/4KdAATp7HWm0mGUGGicMok/e642bd03ca93f52c878a17233d042951/ck-updates.jpeg?w=1272&h=1116&q=50&fit=fill 1272w,
                    //images.ctfassets.net/bktrgw6io7fv/4KdAATp7HWm0mGUGGicMok/e642bd03ca93f52c878a17233d042951/ck-updates.jpeg?w=2000&h=1755&q=50&fit=fill 2000w" src="//images.ctfassets.net/bktrgw6io7fv/4KdAATp7HWm0mGUGGicMok/e642bd03ca93f52c878a17233d042951/ck-updates.jpeg?w=424&h=372&q=50&fit=fill" alt="How To image" style={{ position: "absolute", top: 0, left: 0, opacity: 1, width: "100 % ", height: "100% ", objectFit: "cover", objectPosition: "center" }} /></picture></noscript></div><div class="PopularTopic-icon"><img src="//images.ctfassets.net/bktrgw6io7fv/63TmRtAd68W0aa8msaG22o/a1dcbf563da65b979f78a01db929285e/logo.svg" alt="How To icon" /></div><h2 class="PopularTopic-title">How To</h2></div>
                    </Col>
                    <Col md={3}>
                        <div class="PopularTopic-main"><div class=" gatsby-image-wrapper" style={{ position: "relative", overflow: "hidden" }}><div aria-hidden="true" style={{ width: "100%", paddingBottom: "87.7358%" }}></div><picture><source type="image/webp" srcset="//images.ctfassets.net/bktrgw6io7fv/4KdAATp7HWm0mGUGGicMok/e642bd03ca93f52c878a17233d042951/ck-updates.jpeg?w=106&amp;h=93&amp;q=50&amp;fm=webp&amp;fit=fill 106w,
                    //images.ctfassets.net/bktrgw6io7fv/4KdAATp7HWm0mGUGGicMok/e642bd03ca93f52c878a17233d042951/ck-updates.jpeg?w=212&amp;h=186&amp;q=50&amp;fm=webp&amp;fit=fill 212w,
                    //images.ctfassets.net/bktrgw6io7fv/4KdAATp7HWm0mGUGGicMok/e642bd03ca93f52c878a17233d042951/ck-updates.jpeg?w=424&amp;h=372&amp;q=50&amp;fm=webp&amp;fit=fill 424w,
                    //images.ctfassets.net/bktrgw6io7fv/4KdAATp7HWm0mGUGGicMok/e642bd03ca93f52c878a17233d042951/ck-updates.jpeg?w=636&amp;h=558&amp;q=50&amp;fm=webp&amp;fit=fill 636w,
                    //images.ctfassets.net/bktrgw6io7fv/4KdAATp7HWm0mGUGGicMok/e642bd03ca93f52c878a17233d042951/ck-updates.jpeg?w=848&amp;h=744&amp;q=50&amp;fm=webp&amp;fit=fill 848w,
                    //images.ctfassets.net/bktrgw6io7fv/4KdAATp7HWm0mGUGGicMok/e642bd03ca93f52c878a17233d042951/ck-updates.jpeg?w=1272&amp;h=1116&amp;q=50&amp;fm=webp&amp;fit=fill 1272w,
                    //images.ctfassets.net/bktrgw6io7fv/4KdAATp7HWm0mGUGGicMok/e642bd03ca93f52c878a17233d042951/ck-updates.jpeg?w=2000&amp;h=1755&amp;q=50&amp;fm=webp&amp;fit=fill 2000w" sizes="(max-width: 424px) 100vw, 424px" /><source srcset="//images.ctfassets.net/bktrgw6io7fv/4KdAATp7HWm0mGUGGicMok/e642bd03ca93f52c878a17233d042951/ck-updates.jpeg?w=106&amp;h=93&amp;q=50&amp;fit=fill 106w,
                    //images.ctfassets.net/bktrgw6io7fv/4KdAATp7HWm0mGUGGicMok/e642bd03ca93f52c878a17233d042951/ck-updates.jpeg?w=212&amp;h=186&amp;q=50&amp;fit=fill 212w,
                    //images.ctfassets.net/bktrgw6io7fv/4KdAATp7HWm0mGUGGicMok/e642bd03ca93f52c878a17233d042951/ck-updates.jpeg?w=424&amp;h=372&amp;q=50&amp;fit=fill 424w,
                    //images.ctfassets.net/bktrgw6io7fv/4KdAATp7HWm0mGUGGicMok/e642bd03ca93f52c878a17233d042951/ck-updates.jpeg?w=636&amp;h=558&amp;q=50&amp;fit=fill 636w,
                    //images.ctfassets.net/bktrgw6io7fv/4KdAATp7HWm0mGUGGicMok/e642bd03ca93f52c878a17233d042951/ck-updates.jpeg?w=848&amp;h=744&amp;q=50&amp;fit=fill 848w,
                    //images.ctfassets.net/bktrgw6io7fv/4KdAATp7HWm0mGUGGicMok/e642bd03ca93f52c878a17233d042951/ck-updates.jpeg?w=1272&amp;h=1116&amp;q=50&amp;fit=fill 1272w,
                    //images.ctfassets.net/bktrgw6io7fv/4KdAATp7HWm0mGUGGicMok/e642bd03ca93f52c878a17233d042951/ck-updates.jpeg?w=2000&amp;h=1755&amp;q=50&amp;fit=fill 2000w" sizes="(max-width: 424px) 100vw, 424px" /><img sizes="(max-width: 424px) 100vw, 424px" srcset="//images.ctfassets.net/bktrgw6io7fv/4KdAATp7HWm0mGUGGicMok/e642bd03ca93f52c878a17233d042951/ck-updates.jpeg?w=106&amp;h=93&amp;q=50&amp;fit=fill 106w,
                    //images.ctfassets.net/bktrgw6io7fv/4KdAATp7HWm0mGUGGicMok/e642bd03ca93f52c878a17233d042951/ck-updates.jpeg?w=212&amp;h=186&amp;q=50&amp;fit=fill 212w,
                    //images.ctfassets.net/bktrgw6io7fv/4KdAATp7HWm0mGUGGicMok/e642bd03ca93f52c878a17233d042951/ck-updates.jpeg?w=424&amp;h=372&amp;q=50&amp;fit=fill 424w,
                    //images.ctfassets.net/bktrgw6io7fv/4KdAATp7HWm0mGUGGicMok/e642bd03ca93f52c878a17233d042951/ck-updates.jpeg?w=636&amp;h=558&amp;q=50&amp;fit=fill 636w,
                    //images.ctfassets.net/bktrgw6io7fv/4KdAATp7HWm0mGUGGicMok/e642bd03ca93f52c878a17233d042951/ck-updates.jpeg?w=848&amp;h=744&amp;q=50&amp;fit=fill 848w,
                    //images.ctfassets.net/bktrgw6io7fv/4KdAATp7HWm0mGUGGicMok/e642bd03ca93f52c878a17233d042951/ck-updates.jpeg?w=1272&amp;h=1116&amp;q=50&amp;fit=fill 1272w,
                    //images.ctfassets.net/bktrgw6io7fv/4KdAATp7HWm0mGUGGicMok/e642bd03ca93f52c878a17233d042951/ck-updates.jpeg?w=2000&amp;h=1755&amp;q=50&amp;fit=fill 2000w" src="//images.ctfassets.net/bktrgw6io7fv/4KdAATp7HWm0mGUGGicMok/e642bd03ca93f52c878a17233d042951/ck-updates.jpeg?w=424&amp;h=372&amp;q=50&amp;fit=fill" alt="How To image" loading="lazy" style={{ position: "absolute", top: "0px", left: "0px", width: "100%", height: "100%", objectFit: "cover", objectPosition: "center center", opacity: 1, transition: "none 0s ease 0s" }} /></picture><noscript><picture><source type='image/webp' srcset="//images.ctfassets.net/bktrgw6io7fv/4KdAATp7HWm0mGUGGicMok/e642bd03ca93f52c878a17233d042951/ck-updates.jpeg?w=106&h=93&q=50&fm=webp&fit=fill 106w,
                    //images.ctfassets.net/bktrgw6io7fv/4KdAATp7HWm0mGUGGicMok/e642bd03ca93f52c878a17233d042951/ck-updates.jpeg?w=212&h=186&q=50&fm=webp&fit=fill 212w,
                    //images.ctfassets.net/bktrgw6io7fv/4KdAATp7HWm0mGUGGicMok/e642bd03ca93f52c878a17233d042951/ck-updates.jpeg?w=424&h=372&q=50&fm=webp&fit=fill 424w,
                    //images.ctfassets.net/bktrgw6io7fv/4KdAATp7HWm0mGUGGicMok/e642bd03ca93f52c878a17233d042951/ck-updates.jpeg?w=636&h=558&q=50&fm=webp&fit=fill 636w,
                    //images.ctfassets.net/bktrgw6io7fv/4KdAATp7HWm0mGUGGicMok/e642bd03ca93f52c878a17233d042951/ck-updates.jpeg?w=848&h=744&q=50&fm=webp&fit=fill 848w,
                    //images.ctfassets.net/bktrgw6io7fv/4KdAATp7HWm0mGUGGicMok/e642bd03ca93f52c878a17233d042951/ck-updates.jpeg?w=1272&h=1116&q=50&fm=webp&fit=fill 1272w,
                    //images.ctfassets.net/bktrgw6io7fv/4KdAATp7HWm0mGUGGicMok/e642bd03ca93f52c878a17233d042951/ck-updates.jpeg?w=2000&h=1755&q=50&fm=webp&fit=fill 2000w" sizes="(max-width: 424px) 100vw, 424px" /><source srcset="//images.ctfassets.net/bktrgw6io7fv/4KdAATp7HWm0mGUGGicMok/e642bd03ca93f52c878a17233d042951/ck-updates.jpeg?w=106&h=93&q=50&fit=fill 106w,
                    //images.ctfassets.net/bktrgw6io7fv/4KdAATp7HWm0mGUGGicMok/e642bd03ca93f52c878a17233d042951/ck-updates.jpeg?w=212&h=186&q=50&fit=fill 212w,
                    //images.ctfassets.net/bktrgw6io7fv/4KdAATp7HWm0mGUGGicMok/e642bd03ca93f52c878a17233d042951/ck-updates.jpeg?w=424&h=372&q=50&fit=fill 424w,
                    //images.ctfassets.net/bktrgw6io7fv/4KdAATp7HWm0mGUGGicMok/e642bd03ca93f52c878a17233d042951/ck-updates.jpeg?w=636&h=558&q=50&fit=fill 636w,
                    //images.ctfassets.net/bktrgw6io7fv/4KdAATp7HWm0mGUGGicMok/e642bd03ca93f52c878a17233d042951/ck-updates.jpeg?w=848&h=744&q=50&fit=fill 848w,
                    //images.ctfassets.net/bktrgw6io7fv/4KdAATp7HWm0mGUGGicMok/e642bd03ca93f52c878a17233d042951/ck-updates.jpeg?w=1272&h=1116&q=50&fit=fill 1272w,
                    //images.ctfassets.net/bktrgw6io7fv/4KdAATp7HWm0mGUGGicMok/e642bd03ca93f52c878a17233d042951/ck-updates.jpeg?w=2000&h=1755&q=50&fit=fill 2000w" sizes="(max-width: 424px) 100vw, 424px" /><img loading="lazy" sizes="(max-width: 424px) 100vw, 424px" srcset="//images.ctfassets.net/bktrgw6io7fv/4KdAATp7HWm0mGUGGicMok/e642bd03ca93f52c878a17233d042951/ck-updates.jpeg?w=106&h=93&q=50&fit=fill 106w,
                    //images.ctfassets.net/bktrgw6io7fv/4KdAATp7HWm0mGUGGicMok/e642bd03ca93f52c878a17233d042951/ck-updates.jpeg?w=212&h=186&q=50&fit=fill 212w,
                    //images.ctfassets.net/bktrgw6io7fv/4KdAATp7HWm0mGUGGicMok/e642bd03ca93f52c878a17233d042951/ck-updates.jpeg?w=424&h=372&q=50&fit=fill 424w,
                    //images.ctfassets.net/bktrgw6io7fv/4KdAATp7HWm0mGUGGicMok/e642bd03ca93f52c878a17233d042951/ck-updates.jpeg?w=636&h=558&q=50&fit=fill 636w,
                    //images.ctfassets.net/bktrgw6io7fv/4KdAATp7HWm0mGUGGicMok/e642bd03ca93f52c878a17233d042951/ck-updates.jpeg?w=848&h=744&q=50&fit=fill 848w,
                    //images.ctfassets.net/bktrgw6io7fv/4KdAATp7HWm0mGUGGicMok/e642bd03ca93f52c878a17233d042951/ck-updates.jpeg?w=1272&h=1116&q=50&fit=fill 1272w,
                    //images.ctfassets.net/bktrgw6io7fv/4KdAATp7HWm0mGUGGicMok/e642bd03ca93f52c878a17233d042951/ck-updates.jpeg?w=2000&h=1755&q=50&fit=fill 2000w" src="//images.ctfassets.net/bktrgw6io7fv/4KdAATp7HWm0mGUGGicMok/e642bd03ca93f52c878a17233d042951/ck-updates.jpeg?w=424&h=372&q=50&fit=fill" alt="How To image" style={{ position: "absolute", top: 0, left: 0, opacity: 1, width: "100 % ", height: "100% ", objectFit: "cover", objectPosition: "center" }} /></picture></noscript></div><div class="PopularTopic-icon"><img src="//images.ctfassets.net/bktrgw6io7fv/63TmRtAd68W0aa8msaG22o/a1dcbf563da65b979f78a01db929285e/logo.svg" alt="How To icon" /></div><h2 class="PopularTopic-title">How To</h2></div>
                    </Col>
                    <Col md={3}>
                        <div class="PopularTopic-main"><div class=" gatsby-image-wrapper" style={{ position: "relative", overflow: "hidden" }}><div aria-hidden="true" style={{ width: "100%", paddingBottom: "87.7358%" }}></div><picture><source type="image/webp" srcset="//images.ctfassets.net/bktrgw6io7fv/4KdAATp7HWm0mGUGGicMok/e642bd03ca93f52c878a17233d042951/ck-updates.jpeg?w=106&amp;h=93&amp;q=50&amp;fm=webp&amp;fit=fill 106w,
                    //images.ctfassets.net/bktrgw6io7fv/4KdAATp7HWm0mGUGGicMok/e642bd03ca93f52c878a17233d042951/ck-updates.jpeg?w=212&amp;h=186&amp;q=50&amp;fm=webp&amp;fit=fill 212w,
                    //images.ctfassets.net/bktrgw6io7fv/4KdAATp7HWm0mGUGGicMok/e642bd03ca93f52c878a17233d042951/ck-updates.jpeg?w=424&amp;h=372&amp;q=50&amp;fm=webp&amp;fit=fill 424w,
                    //images.ctfassets.net/bktrgw6io7fv/4KdAATp7HWm0mGUGGicMok/e642bd03ca93f52c878a17233d042951/ck-updates.jpeg?w=636&amp;h=558&amp;q=50&amp;fm=webp&amp;fit=fill 636w,
                    //images.ctfassets.net/bktrgw6io7fv/4KdAATp7HWm0mGUGGicMok/e642bd03ca93f52c878a17233d042951/ck-updates.jpeg?w=848&amp;h=744&amp;q=50&amp;fm=webp&amp;fit=fill 848w,
                    //images.ctfassets.net/bktrgw6io7fv/4KdAATp7HWm0mGUGGicMok/e642bd03ca93f52c878a17233d042951/ck-updates.jpeg?w=1272&amp;h=1116&amp;q=50&amp;fm=webp&amp;fit=fill 1272w,
                    //images.ctfassets.net/bktrgw6io7fv/4KdAATp7HWm0mGUGGicMok/e642bd03ca93f52c878a17233d042951/ck-updates.jpeg?w=2000&amp;h=1755&amp;q=50&amp;fm=webp&amp;fit=fill 2000w" sizes="(max-width: 424px) 100vw, 424px" /><source srcset="//images.ctfassets.net/bktrgw6io7fv/4KdAATp7HWm0mGUGGicMok/e642bd03ca93f52c878a17233d042951/ck-updates.jpeg?w=106&amp;h=93&amp;q=50&amp;fit=fill 106w,
                    //images.ctfassets.net/bktrgw6io7fv/4KdAATp7HWm0mGUGGicMok/e642bd03ca93f52c878a17233d042951/ck-updates.jpeg?w=212&amp;h=186&amp;q=50&amp;fit=fill 212w,
                    //images.ctfassets.net/bktrgw6io7fv/4KdAATp7HWm0mGUGGicMok/e642bd03ca93f52c878a17233d042951/ck-updates.jpeg?w=424&amp;h=372&amp;q=50&amp;fit=fill 424w,
                    //images.ctfassets.net/bktrgw6io7fv/4KdAATp7HWm0mGUGGicMok/e642bd03ca93f52c878a17233d042951/ck-updates.jpeg?w=636&amp;h=558&amp;q=50&amp;fit=fill 636w,
                    //images.ctfassets.net/bktrgw6io7fv/4KdAATp7HWm0mGUGGicMok/e642bd03ca93f52c878a17233d042951/ck-updates.jpeg?w=848&amp;h=744&amp;q=50&amp;fit=fill 848w,
                    //images.ctfassets.net/bktrgw6io7fv/4KdAATp7HWm0mGUGGicMok/e642bd03ca93f52c878a17233d042951/ck-updates.jpeg?w=1272&amp;h=1116&amp;q=50&amp;fit=fill 1272w,
                    //images.ctfassets.net/bktrgw6io7fv/4KdAATp7HWm0mGUGGicMok/e642bd03ca93f52c878a17233d042951/ck-updates.jpeg?w=2000&amp;h=1755&amp;q=50&amp;fit=fill 2000w" sizes="(max-width: 424px) 100vw, 424px" /><img sizes="(max-width: 424px) 100vw, 424px" srcset="//images.ctfassets.net/bktrgw6io7fv/4KdAATp7HWm0mGUGGicMok/e642bd03ca93f52c878a17233d042951/ck-updates.jpeg?w=106&amp;h=93&amp;q=50&amp;fit=fill 106w,
                    //images.ctfassets.net/bktrgw6io7fv/4KdAATp7HWm0mGUGGicMok/e642bd03ca93f52c878a17233d042951/ck-updates.jpeg?w=212&amp;h=186&amp;q=50&amp;fit=fill 212w,
                    //images.ctfassets.net/bktrgw6io7fv/4KdAATp7HWm0mGUGGicMok/e642bd03ca93f52c878a17233d042951/ck-updates.jpeg?w=424&amp;h=372&amp;q=50&amp;fit=fill 424w,
                    //images.ctfassets.net/bktrgw6io7fv/4KdAATp7HWm0mGUGGicMok/e642bd03ca93f52c878a17233d042951/ck-updates.jpeg?w=636&amp;h=558&amp;q=50&amp;fit=fill 636w,
                    //images.ctfassets.net/bktrgw6io7fv/4KdAATp7HWm0mGUGGicMok/e642bd03ca93f52c878a17233d042951/ck-updates.jpeg?w=848&amp;h=744&amp;q=50&amp;fit=fill 848w,
                    //images.ctfassets.net/bktrgw6io7fv/4KdAATp7HWm0mGUGGicMok/e642bd03ca93f52c878a17233d042951/ck-updates.jpeg?w=1272&amp;h=1116&amp;q=50&amp;fit=fill 1272w,
                    //images.ctfassets.net/bktrgw6io7fv/4KdAATp7HWm0mGUGGicMok/e642bd03ca93f52c878a17233d042951/ck-updates.jpeg?w=2000&amp;h=1755&amp;q=50&amp;fit=fill 2000w" src="//images.ctfassets.net/bktrgw6io7fv/4KdAATp7HWm0mGUGGicMok/e642bd03ca93f52c878a17233d042951/ck-updates.jpeg?w=424&amp;h=372&amp;q=50&amp;fit=fill" alt="How To image" loading="lazy" style={{ position: "absolute", top: "0px", left: "0px", width: "100%", height: "100%", objectFit: "cover", objectPosition: "center center", opacity: 1, transition: "none 0s ease 0s" }} /></picture><noscript><picture><source type='image/webp' srcset="//images.ctfassets.net/bktrgw6io7fv/4KdAATp7HWm0mGUGGicMok/e642bd03ca93f52c878a17233d042951/ck-updates.jpeg?w=106&h=93&q=50&fm=webp&fit=fill 106w,
                    //images.ctfassets.net/bktrgw6io7fv/4KdAATp7HWm0mGUGGicMok/e642bd03ca93f52c878a17233d042951/ck-updates.jpeg?w=212&h=186&q=50&fm=webp&fit=fill 212w,
                    //images.ctfassets.net/bktrgw6io7fv/4KdAATp7HWm0mGUGGicMok/e642bd03ca93f52c878a17233d042951/ck-updates.jpeg?w=424&h=372&q=50&fm=webp&fit=fill 424w,
                    //images.ctfassets.net/bktrgw6io7fv/4KdAATp7HWm0mGUGGicMok/e642bd03ca93f52c878a17233d042951/ck-updates.jpeg?w=636&h=558&q=50&fm=webp&fit=fill 636w,
                    //images.ctfassets.net/bktrgw6io7fv/4KdAATp7HWm0mGUGGicMok/e642bd03ca93f52c878a17233d042951/ck-updates.jpeg?w=848&h=744&q=50&fm=webp&fit=fill 848w,
                    //images.ctfassets.net/bktrgw6io7fv/4KdAATp7HWm0mGUGGicMok/e642bd03ca93f52c878a17233d042951/ck-updates.jpeg?w=1272&h=1116&q=50&fm=webp&fit=fill 1272w,
                    //images.ctfassets.net/bktrgw6io7fv/4KdAATp7HWm0mGUGGicMok/e642bd03ca93f52c878a17233d042951/ck-updates.jpeg?w=2000&h=1755&q=50&fm=webp&fit=fill 2000w" sizes="(max-width: 424px) 100vw, 424px" /><source srcset="//images.ctfassets.net/bktrgw6io7fv/4KdAATp7HWm0mGUGGicMok/e642bd03ca93f52c878a17233d042951/ck-updates.jpeg?w=106&h=93&q=50&fit=fill 106w,
                    //images.ctfassets.net/bktrgw6io7fv/4KdAATp7HWm0mGUGGicMok/e642bd03ca93f52c878a17233d042951/ck-updates.jpeg?w=212&h=186&q=50&fit=fill 212w,
                    //images.ctfassets.net/bktrgw6io7fv/4KdAATp7HWm0mGUGGicMok/e642bd03ca93f52c878a17233d042951/ck-updates.jpeg?w=424&h=372&q=50&fit=fill 424w,
                    //images.ctfassets.net/bktrgw6io7fv/4KdAATp7HWm0mGUGGicMok/e642bd03ca93f52c878a17233d042951/ck-updates.jpeg?w=636&h=558&q=50&fit=fill 636w,
                    //images.ctfassets.net/bktrgw6io7fv/4KdAATp7HWm0mGUGGicMok/e642bd03ca93f52c878a17233d042951/ck-updates.jpeg?w=848&h=744&q=50&fit=fill 848w,
                    //images.ctfassets.net/bktrgw6io7fv/4KdAATp7HWm0mGUGGicMok/e642bd03ca93f52c878a17233d042951/ck-updates.jpeg?w=1272&h=1116&q=50&fit=fill 1272w,
                    //images.ctfassets.net/bktrgw6io7fv/4KdAATp7HWm0mGUGGicMok/e642bd03ca93f52c878a17233d042951/ck-updates.jpeg?w=2000&h=1755&q=50&fit=fill 2000w" sizes="(max-width: 424px) 100vw, 424px" /><img loading="lazy" sizes="(max-width: 424px) 100vw, 424px" srcset="//images.ctfassets.net/bktrgw6io7fv/4KdAATp7HWm0mGUGGicMok/e642bd03ca93f52c878a17233d042951/ck-updates.jpeg?w=106&h=93&q=50&fit=fill 106w,
                    //images.ctfassets.net/bktrgw6io7fv/4KdAATp7HWm0mGUGGicMok/e642bd03ca93f52c878a17233d042951/ck-updates.jpeg?w=212&h=186&q=50&fit=fill 212w,
                    //images.ctfassets.net/bktrgw6io7fv/4KdAATp7HWm0mGUGGicMok/e642bd03ca93f52c878a17233d042951/ck-updates.jpeg?w=424&h=372&q=50&fit=fill 424w,
                    //images.ctfassets.net/bktrgw6io7fv/4KdAATp7HWm0mGUGGicMok/e642bd03ca93f52c878a17233d042951/ck-updates.jpeg?w=636&h=558&q=50&fit=fill 636w,
                    //images.ctfassets.net/bktrgw6io7fv/4KdAATp7HWm0mGUGGicMok/e642bd03ca93f52c878a17233d042951/ck-updates.jpeg?w=848&h=744&q=50&fit=fill 848w,
                    //images.ctfassets.net/bktrgw6io7fv/4KdAATp7HWm0mGUGGicMok/e642bd03ca93f52c878a17233d042951/ck-updates.jpeg?w=1272&h=1116&q=50&fit=fill 1272w,
                    //images.ctfassets.net/bktrgw6io7fv/4KdAATp7HWm0mGUGGicMok/e642bd03ca93f52c878a17233d042951/ck-updates.jpeg?w=2000&h=1755&q=50&fit=fill 2000w" src="//images.ctfassets.net/bktrgw6io7fv/4KdAATp7HWm0mGUGGicMok/e642bd03ca93f52c878a17233d042951/ck-updates.jpeg?w=424&h=372&q=50&fit=fill" alt="How To image" style={{ position: "absolute", top: 0, left: 0, opacity: 1, width: "100 % ", height: "100% ", objectFit: "cover", objectPosition: "center" }} /></picture></noscript></div><div class="PopularTopic-icon"><img src="//images.ctfassets.net/bktrgw6io7fv/63TmRtAd68W0aa8msaG22o/a1dcbf563da65b979f78a01db929285e/logo.svg" alt="How To icon" /></div><h2 class="PopularTopic-title">How To</h2></div>
                    </Col>
                </Row>
            </Container>
        </div>
    )
}

export default BlogNav
