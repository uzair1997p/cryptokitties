import { Container, Row, Col } from 'react-bootstrap';
import { Link } from "react-router-dom"
const HeaderNav = () => {
    return (
        <div>

            <Container fluid style={{
                backgroundImage: "url('https://www.cryptokitties.co/images/pattern-tile.svg')",
                backgroundColor: "rgb(249, 248, 246)",
                backgroundSize: "50rem",
                textAlign: "center",
                // height: "130px"


            }}>

                <Row   >

                    <Col md={1} sm={1} xs={2} className="border mt-5 mb-5 ml-auto bg-white rounded text-center ml-4" >
                        <Link to="/about">

                            About
                        </Link>
                    </Col>
                    <Col md={1} sm={1} xs={2} className="border mt-5 mb-5  bg-white rounded text-center ml-4" >
                        <Link to="/press">

                            Press
                        </Link>
                    </Col>
                    <Col md={1} sm={1} xs={2} className="border mt-5 mb-5  bg-white rounded text-center ml-4" >
                        <Link to="/technical-page">

                            Technical Details
                        </Link>
                    </Col>
                    <Col md={1} sm={1} xs={2} className="border mt-5 mb-5 mr-auto bg-white rounded text-center ml-4" >

                        <a href="https://drive.google.com/file/d/1soo-eAaJHzhw_XhFGMJp3VNcQoM43byS/view" target="_blank">

                            White Pa-Purr
                        </a>

                    </Col>
                </Row>

            </Container>
        </div>
    )
}

export default HeaderNav
