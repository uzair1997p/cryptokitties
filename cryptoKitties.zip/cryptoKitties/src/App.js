import { BrowserRouter as Router } from "react-router-dom";
import Routes from "./Routers/Routers";
 
import './App.css';

function App() {
  return (
    <div className="">
      <Router>
        <Routes />

      </Router>

    </div>
  );
}

export default App;
