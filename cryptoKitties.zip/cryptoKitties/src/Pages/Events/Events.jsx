import NavBar from '../../Components/Navbar/NavBar';
import Footer from '../../Components/Footer/Footer';
import { Container, Row, Col } from 'react-bootstrap';
import './Events.css';

const Events = () => {
    return (
        <>
            <NavBar />
            <Container className=" ml-auto mr-auto" >
                <Row className=" offset-md-2  ">
                    <Col className="" md={10}>
                        <p>
                            <h1 className="CryptoKitties">
                                CryptoKitties Current Events
                            </h1>
                        </p>
                        <p>
                            <h3 className="CryptoKitties">
                                The Kitty #2,000,000th and the last Gale!
                            </h3>
                        </p>

                    </Col>
                    <Col className="" md={10}>
                        <div className="  "

                            style={{
                                backgroundImage: "url('https://images.ctfassets.net/bktrgw6io7fv/1A1wvdsHZ7ypQmQNU1yDjc/42a508ba19cae4a7831e78b59739b871/2.0Cat_02__2014X535.png')",
                                backgroundSize: "cover",
                                width: "100%",
                                height: "300px",
                                backgroundRepeat: "no-repeat",
                                backgroundPosition: "center"

                            }}
                        ></div>
                        <div className="    ">

                            <p className="">
                                Congratulations to our community member, CryptoKittyMagic, for breeding the 2,000,000th CryptoKitty - a Pumpernickel Exclusive! This Kitty joins the collection of 36 Gales that were mostly bred by players. In the race to Kitty 2 million, 35 Gales were discovered by our community and one Gale #1978787 was bred in our Gen-1 SE account and raffled in a trustless drawing. This raffle was won by
                            </p>

                            <p className="">
                                0xadad5e55b1ca79c9c109b0cf67051de8420b8a7f and we've reached out to this new player to let them know of the new addition to their collection!
                            </p>
                            <p>
                                The only eligibility requirement to enter the drawing was to have bred a Kitty between IDs 1,997,286 (the last Gale) and 2,000,000. Each breed counted as one entry.
                            </p>
                            <p>
                                Here are the entries in the exact order of Kitties bred. We assigned an entry number to each breeder. If you bred multiple Kitties, you received multiple entries.
                            </p>

                            <p>
                                The rules we used to determine the winner:
                            </p>

                            <p>
                                <ul>
                                    <li>We'll use Ethereum block #12612345</li>
                                    <li>After that block is mined and fully confirmed (10 confirmations) we'll convert the hash of that block to a decimal value.</li>
                                    <li>
                                        We'll use the last 9 digits of that value as the dividend, with a divisor of the number of valid entries (
                                    </li>
                                </ul>
                            </p>

                        </div>
                    </Col>
                    <Col md={10}>
                        <p>
                            <h3>
                                An Elephantastic Fancy!
                            </h3>
                        </p>
                        <div style={{
                            backgroundImage: "url('https://images.ctfassets.net/bktrgw6io7fv/28nUbjgNqce7pxvKuFpktG/aca7dcda5b66025118c763162e27dcb8/SP_Ellie-found_shiny.png')",
                            backgroundSize: "cover",
                            width: "100%",
                            height: "300px",
                            backgroundRepeat: "no-repeat",
                            backgroundPosition: "center"
                        }}>

                        </div>
                        <div>
                            <p>The first of our next Fancy Family has been released into the wild, and the community worked together to solve the clues and find the required recipe traits on Twitter and Twitch! Congratulations to KatieLorrie and for being the first to breed our newest Shiny-enabled Fancy, Ellie! You can use the following recipe to join in on the chase: shadowgrey, flamingo, littlefoot, and walrus.</p>
                        </div>

                        <h3>
                            Breeding fees for our upcoming Fancy Chases
                        </h3>
                        <p>
                            As you may know, the breeding fee is currently fluctuating beyond 0.008 ETH. This is due to the sustained increase in gas prices on the ethereum network. These gas prices directly affect the cost for autobirthers to birth your Kitties.
                        </p>
                        <p>Because of high gas prices, some of your Kitties have failed to give birth in a timely manner as there is no incentive for autobirthers when the cost to birth your cat exceeds the breeding fee reward. It's important that the breeding fee is always above the cost to give birth to a Kitty so that your Kitties can be birthed in a timely manner especially during a Fancy chase.</p>

                        <p>We understand how important it is to have a predictable breeding fee so that you can make an informed decision to participate in this Fancy chase.</p>


                        <p>Unfortunately, there are no guarantees that gas will decrease. There are also no guarantees that it won't increase. The breeding fee requires flexibility to be updated so that cats can get birthed quickly during the upcoming window.</p>
                        <p>We can commit to predictably updating the breeding fee at 9:00am and 9:00pm PST on most days. We will average OUR autobirther's giveBirth transaction costs over the previous 12 hour period and update the fee with guidance from this table.</p>
                        <p>We reserve the right to forego a fee update if we feel like it will be in the best interest for players. One example could be a large sustained spike at 8:00pm.</p>
                        <div style={{
                            backgroundImage: "url('https://images.ctfassets.net/bktrgw6io7fv/50Pdx97x4BEJA2Hk4uybAK/3d3d487e565f95e824a2ea037661728a/Screen_Shot_2020-05-22_at_12.09.55_PM.png')",
                            backgroundSize: "cover",
                            width: "100%",
                            height: "400px",
                            backgroundRepeat: "no-repeat",
                            backgroundPosition: "center"
                        }}>

                        </div>
                        <p>
                            We understand these are complicated circumstances and we are open to hearing your thoughts for other viable alternatives that we could explore in the future.
                        </p>
                    </Col>
                    <Col md={10}>
                        <p>
                            <h3>
                                Breed a full set of Purrior Kitties
                            </h3>
                        </p>
                        <div
                            style={{
                                backgroundImage: "url('https://images.ctfassets.net/bktrgw6io7fv/2Ya8fiIB5yrxByphA4cXcz/8d1232ace3af6afe3dff95ff4fc5715a/page-events.jpg')",
                                backgroundSize: "cover",
                                width: "100%",
                                height: "400px",
                                backgroundRepeat: "no-repeat",
                                backgroundPosition: "center"
                            }}
                        ></div>
                        <p>
                            If you've never chased a Fancy before, it's easy to get started with Page, a very good and clever kitten with a lot to offer the world! The recipe to breed a Page is relatively simple, requiring only these three Cattributes:
                        </p>
                        <p>
                            <ul>
                                <li>
                                    Cattribute #1: wasntme</li>
                                <li>
                                    Cattribute #2: peach</li>
                                <li>
                                    Cattribute #3: rascal</li>
                            </ul>
                        </p>
                        <p>
                            Find cats with these Cattributes and start chasing your first Fancy cat now!

                        </p>

                    </Col>
                    <Col md={10}>
                        <div style={{
                            backgroundImage: "url('https://images.ctfassets.net/bktrgw6io7fv/4R5DU3QeCFKB274qCTBmIc/be3878f861ab049d05f6e9af1dda0f6d/PageGangSword1_2014x535.png')",
                            backgroundSize: "cover",
                            width: "100%",
                            height: "400px",
                            backgroundRepeat: "no-repeat",
                            backgroundPosition: "center"
                        }}>

                        </div>
                        <p>
                            Gwendolion the Champion is the latest addition to Page's Warriors! Follow the recipe for this starter Fancy to create a great breeding foundation for the rest of Page's warriors.
                        </p>


                        <p>
                            <ul>
                                <li>
                                    Cattribute #1: burmilla

                                </li>
                                <li>
                                    Cattribute #2: salmon
                                </li>
                                <li>
                                    Cattribute #3: icy

                                </li>
                            </ul>
                        </p>
                        <p>Gwendolion is Shiny-enabled! Each Gwendolion bred from non-Gwendolion parents will have a chance to be born as an incredibly rare Shiny version featuring alternate colouring.

                        </p>

                    </Col>
                    <Col md={10}>
                    </Col>
                </Row>

            </Container>
            <Footer />
        </>
    )
}

export default Events
