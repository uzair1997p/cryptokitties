import NavBar from "../../Components/Navbar/NavBar";
import Footer from "../../Components/Footer/Footer";

import { Container, Row, Col, Card, Button } from "react-bootstrap";

const KittyVerse = () => {
    return (
        <div>
            <NavBar />
            <Container>
                <div className=" text-center">
                    <img className="img-fluid w-25 h-25" src="https://www.cryptokitties.co/images/kittyverse/logomark.svg" />
                </div>
                <div className="text-center">
                    <img className="img-fluid w-25 h-25" src="https://www.cryptokitties.co/images/kittyverse/logo.svg" />
                </div>
                <p>Your CryptoKitty unlocks a universe of infinite experiences.</p>
                <h1 className="text-center ">Take your Kitties to new heights</h1>
                <p>You can still breed and collect your CryptoKitties – but now you can also compete in leaderboards, send your cats to participate in literal catfights, and much more!</p>

                <Row>
                    <Col md={4} sm={6} xs={8} className="mb-5">
                        <Card style={{ width: '18rem' }}>
                            <Card.Body>
                                <img className="img-fluid w-25 h-25" src="https://www.cryptokitties.co/images/kittyverse/kittyhelper-logo.png" />
                                <Card.Text>KittyHelper </Card.Text>
                                <Card.Subtitle className="mb-2 text-muted">kittyhelper.co</Card.Subtitle>
                            </Card.Body>
                        </Card>
                    </Col>

                    <Col md={4} sm={6} xs={8} className="mb-5">
                        <Card style={{ width: '18rem' }}>
                            <Card.Body>
                                <img className="img-fluid w-25 h-25" src="https://www.cryptokitties.co/images/kittyverse/kotowars-logo.png" />
                                <Card.Text>
                                    KotoWars
                                </Card.Text>
                                <Card.Subtitle className="mb-2 text-muted">kotowars.com </Card.Subtitle>
                            </Card.Body>
                        </Card>
                    </Col>

                    <Col md={4} sm={6} xs={8} className="mb-5">
                        <Card style={{ width: '18rem' }}>
                            <Card.Body>
                                <img className="img-fluid w-25 h-25" src="https://www.cryptokitties.co/images/kittyverse/ckbox-logo.png" />
                                <Card.Text>
                                    CKBox
                                </Card.Text>
                                <Card.Subtitle className="mb-2 text-muted">ckbox.co</Card.Subtitle>
                            </Card.Body>
                        </Card>
                    </Col>
                </Row>

                <Row>
                    <Col md={4} sm={6} xs={8} className="mb-5">
                        <Card style={{ width: '18rem' }}>
                            <Card.Body>
                                <img className="img-fluid w-25 h-25" src="https://www.cryptokitties.co/images/kittyverse/heavencat-logo.png" />
                                <Card.Text>Heaven.cat</Card.Text>
                                <Card.Subtitle className="mb-2 text-muted">heaven.cat</Card.Subtitle>
                            </Card.Body>
                        </Card>
                    </Col>

                    <Col md={4} sm={6} xs={8} className="mb-5">
                        <Card style={{ width: '18rem' }}>
                            <Card.Body>
                                <img className="img-fluid w-25 h-25" src="https://www.cryptokitties.co/images/kittyverse/wrappedkitties-logo.png" />
                                <Card.Text>
                                    WrappedKitties
                                </Card.Text>
                                <Card.Subtitle className="mb-2 text-muted">wrappedkitties.com </Card.Subtitle>
                            </Card.Body>
                        </Card>
                    </Col>

                    <Col md={4} sm={6} xs={8} className="mb-5">
                        <Card style={{ width: '18rem' }}>
                            <Card.Body>
                                <img className="img-fluid w-25 h-25" src="https://www.cryptokitties.co/images/kittyverse/kotobaza-logo.png" />
                                <Card.Text>
                                    KotoBaza
                                </Card.Text>
                                <Card.Subtitle className="mb-2 text-muted">blog.kotobaza.co</Card.Subtitle>
                            </Card.Body>
                        </Card>
                    </Col>
                </Row>

                <Row>
                    <Col md={4} sm={6} xs={8} className="mb-5">
                        <Card style={{ width: '18rem' }}>
                            <Card.Body>
                                <img className="img-fluid w-25 h-25" className="img-fluid w-25 h-25" src="https://www.cryptokitties.co/images/kittyverse/cryptomibs-logo.png" />
                                <Card.Text>CryptoMibs</Card.Text>
                                <Card.Subtitle className="mb-2 text-muted">cryptomibs.io</Card.Subtitle>
                            </Card.Body>
                        </Card>
                    </Col>

                    <Col md={4} sm={6} xs={8} className="mb-5">
                        <Card style={{ width: '18rem' }}>
                            <Card.Body>
                                <img className="img-fluid w-25 h-25" src="https://www.cryptokitties.co/images/kittyverse/catatonic-logo.svg" />
                                <Card.Text>
                                    Catatonic Club
                                </Card.Text>
                                <Card.Subtitle className="mb-2 text-muted">catatonic.club</Card.Subtitle>
                            </Card.Body>
                        </Card>
                    </Col>

                    <Col md={12} >
                        <Button variant="secondary">Play KittyVerse Games</Button>{' '}
                    </Col>
                </Row>
                <div>
                    <Card>
                        <Card.Body>
                            <h2>The future is meow!</h2>
                            <Card.Subtitle className="mb-2 text-muted">CryptoKitties is built on blockchain technology. One of most exciting aspects of this technology is that it empowers extensible design and development. Basically, if an idea proves itself (like CryptoKitties), people can easily build on top of it.
                                Players get new experiences. Creators get access to an active player base, a proven concept, and a whole host of development resources. And everyone involved has a stake in the future they are helping to shape.
                                This extensibility makes it possible for community creators, developers, and founders to: <br />
                                <ul>
                                    <li> Earn real value from the digital assets and experiences they own and shape </li>
                                    <li>Leverage an existing concept and playerbase (like the CryptoKitties community) for their independent or complementary kitty-flavoured project</li>
                                    <li>Use existing code and open-source resources to create a project in next to no time (via the CryptoKitties Developurr program)</li>
                                </ul>
                                And there’s no middleman or gatekeeper – just you, your ideas, and your favourite furry friend.
                            </Card.Subtitle>
                        </Card.Body>
                    </Card>
                </div>
                <h1>Be part of the future!</h1>
                <p>We’ve created a couple programs to make it easier for you create with the Kitties.</p>
                <Row>

                    <Col md={6}>
                        <Card style={{ width: '25rem' }}>
                            <Card.Body>
                                <img className="img-fluid w-25 h-25" className="img-fluid w-25 h-25" src="https://www.cryptokitties.co/images/kittyverse/programLaunch.svg" />
                                <Card.Subtitle className="mb-2 text-muted">The LaunchPad Program is for anyone that wants to turn their hack into a business
                                    <ul>
                                        <li> Get an access token for the API</li>
                                        <li>Have your project featured by CryptoKitties</li>
                                        <li>Access to office hours from the CryptoKitties team</li>
                                    </ul>
                                </Card.Subtitle>
                                <Button variant="secondary">Secondary</Button>{' '}
                            </Card.Body>
                        </Card>
                    </Col>

                    <Col md={6}>
                        <Card style={{ width: '25rem' }}>
                            <Card.Body>
                                <img className="img-fluid w-25 h-25" src="https://www.cryptokitties.co/images/kittyverse/programDev.svg" />
                                <Card.Subtitle className="mb-2 text-muted">The LaunchPad Program is for anyone that wants to turn their hack into a business
                                    <ul>
                                        <li> Apply for funding to help bootstrap the project </li>
                                        <li>Mentorship from the CryptoKitties team and our advisors</li>
                                        <li>All expenses paid trip to visit the CryptoKitties HQ and workshop with the team</li>
                                    </ul>
                                </Card.Subtitle>
                                <Button variant="secondary">Secondary</Button>{' '}
                            </Card.Body>
                        </Card>
                    </Col>

                </Row>
            </Container>
            <Footer />
        </div>
    );
};

export default KittyVerse;