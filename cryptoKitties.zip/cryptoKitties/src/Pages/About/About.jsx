import { height } from 'dom-helpers';
import { Container, Row, Col } from 'react-bootstrap';
import NavBar from '../../Components/Navbar/NavBar';
import HeaderNav from '../../Components/HeaderNav/HeaderNav';

import Footer from '../../Components/Footer/Footer'
import './About.css';

const About = () => {
    return (
        <div>
            <NavBar />
            <HeaderNav />
            <Container fluid >
                <Row>
                    <Col md={12}>
                        <div className="d-flex justify-content-center mt-5 ">
                            <img src="https://www.cryptokitties.co/images/letterHead.png" height="60px" alt="" />

                        </div>

                        <div className="text-left w-50 offset-3">
                            <p>
                                In CryptoKitties, users collect and breed oh-so-adorable creatures that we call CryptoKitties!Each kitty has a unique genome that defines its appearance and traits.Players can breed their kitties to create new furry friends and unlock rare cattributes.
                            </p>
                            <p>
                                CryptoKitties is one of the world’s first blockchain games.‘Blockchain’ is the technology that makes things like Bitcoin possible.While CryptoKitties isn’t a digital currency, it does offer the same security: each CryptoKitty is one-of-a-kind and 100% owned by you.It cannot be replicated, taken away, or destroyed.
                            </p>
                        </div>
                    </Col>
                </Row>

            </Container>
            <Container>
                <Row className="offset-1">
                    <Col md={4} sm={6} xs={12} className="d-flex justify-content-center mb-4" >
                        <div class="AboutPage-teamMember"><div class="AboutPage-teamPhoto"><img src="https://www.cryptokitties.co/team/jordan_soriani.png" alt="Team photo" /><img class="AboutPage-teamPhotoHover" src="https://www.cryptokitties.co/profile/profile-1.png" alt="Team photo" /></div><p><strong>Jordan Castro</strong><br />Product</p></div>

                    </Col>
                    <Col md={4} sm={6} xs={12} className="d-flex justify-content-center mb-4">
                        <div class="AboutPage-teamMember"><div class="AboutPage-teamPhoto"><img src="https://www.cryptokitties.co/team/jordan_soriani.png" alt="Team photo" /><img class="AboutPage-teamPhotoHover" src="https://www.cryptokitties.co/profile/profile-1.png" alt="Team photo" /></div><p><strong>Jordan Castro</strong><br />Product</p></div>

                    </Col>
                    <Col md={4} sm={6} xs={12} className="d-flex justify-content-center mb-4">
                        <div class="AboutPage-teamMember"><div class="AboutPage-teamPhoto"><img src="https://www.cryptokitties.co/team/jordan_soriani.png" alt="Team photo" /><img class="AboutPage-teamPhotoHover" src="https://www.cryptokitties.co/profile/profile-1.png" alt="Team photo" /></div><p><strong>Jordan Castro</strong><br />Product</p></div>

                    </Col>
                    <Col md={4} sm={6} xs={12} className="d-flex justify-content-center mb-4" >
                        <div class="AboutPage-teamMember"><div class="AboutPage-teamPhoto"><img src="https://www.cryptokitties.co/team/jordan_soriani.png" alt="Team photo" /><img class="AboutPage-teamPhotoHover" src="https://www.cryptokitties.co/profile/profile-1.png" alt="Team photo" /></div><p><strong>Jordan Castro</strong><br />Product</p></div>

                    </Col>
                    <Col md={4} sm={6} xs={12} className="d-flex justify-content-center mb-4">
                        <div class="AboutPage-teamMember"><div class="AboutPage-teamPhoto"><img src="https://www.cryptokitties.co/team/jordan_soriani.png" alt="Team photo" /><img class="AboutPage-teamPhotoHover" src="https://www.cryptokitties.co/profile/profile-1.png" alt="Team photo" /></div><p><strong>Jordan Castro</strong><br />Product</p></div>

                    </Col>
                    <Col md={4} sm={6} xs={12} className="d-flex justify-content-center mb-4">
                        <div class="AboutPage-teamMember"><div class="AboutPage-teamPhoto"><img src="https://www.cryptokitties.co/team/jordan_soriani.png" alt="Team photo" /><img class="AboutPage-teamPhotoHover" src="https://www.cryptokitties.co/profile/profile-1.png" alt="Team photo" /></div><p><strong>Jordan Castro</strong><br />Product</p></div>

                    </Col>
                </Row>
            </Container>
            <Container>
                <Row>
                    <Col md={12} className="d-flex justify-content-center" >
                        <div className="w-75">
                            <p>
                                THE CRYPTOKITTIES CATIFESTO
                            </p>
                            <h1 className="">
                                What we believe in, what we stand for, and why we’re building CryptoKitties.
                            </h1>
                        </div>
                    </Col>
                    <Col md={6}>
                        <div className="w-75 ml-auto">
                            <p>
                                <b>
                                    The future is exciting.

                                </b>
                            </p>
                            <p>
                                And we believe that blockchain is the future—but blockchain is about as approachable as a bunch of ones and zeroes.

                            </p>
                            <p>

                                We want a future for everyone, not one exclusive to Bitcoin miners, VCs, ICOs, and other equally fun acronyms.
                            </p>
                            <p>
                                <b>
                                    So why cats?


                                </b>
                            </p>
                            <p>
                                Pop quiz, hotshot: why not?

                            </p>
                            <p>

                                Cats are impossible to understand.They’re ambassadors for pharaohs, memes, and your mom’s facebook page.
                            </p>
                        </div>

                    </Col>
                    <Col md={6} className="">
                        <div className="w-75 ">

                            <p>
                                They don’t discriminate; they despise everyone equally.


                            </p>
                            <p>
                                Cats are perfect killing machines, with retractable claws, night vision, and teeth on their tongue.But cats also nap whenever they feel like it, and we respect that.

                            </p>
                            <p>

                                More than anything, cats are different.They’re weird, funny, and hopelessly entertaining.You don’t have to understand cats to appreciate them.

                            </p>
                            <p>

                                We’re not trying to build the future—we’re trying to have fun with it.
                            </p>
                        </div>
                    </Col>
                </Row>
            </Container>
            <Footer />
        </div >
    )
}

export default About
