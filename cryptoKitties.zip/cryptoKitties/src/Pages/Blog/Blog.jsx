import BlogNav from '../../Components/BlogNav/BlogNav';


const Blog = () => {
    return (
        <div>
            <BlogNav />
        </div>
    )
}

export default Blog
