import NavBar from '../../Components/Navbar/NavBar';
import HeaderNav from '../../Components/HeaderNav/HeaderNav';
import Footer from "../../Components/Footer/Footer"
import { Container, Row, Col } from 'react-bootstrap';
import './Press.css'

const Press = () => {
    return (
        <div>
            <NavBar />
            <HeaderNav />

            <Container>
                <Row>
                    <Col md={12} >
                        <div className="text-left w-50 offset-3 ">

                            <h1>
                                For Press

                            </h1>
                            <p>
                                CryptoKitties are collectible and breedable digital cats. It’s the world’s first game built on the Ethereum network. When two CryptoKitties breed, their offspring’s appearance and cattributes are determined by each parent’s 256-bit genome and an element of chance, leading to 4-billion possible genetic variations.


                            </p>
                            <p>
                                CryptoKitties was created to explore the concept of digital scarcity, implement a non-fungible token within smart contracts ERC #721, and make blockchain technology accessible to everyday consumers.
                            </p>
                        </div>
                    </Col>
                    <Col md={12}>
                        <div className="   ">

                            <div class="PressPage-facts w-50 offset-3">
                                <Row>
                                    <Col md={4}>
                                        <div class="PressPage-facts-item col-md-3">
                                            <img src="https://www.cryptokitties.co/icons/celebrate.svg" alt="Founded" />
                                            <p class="PressPage-facts-p">Founded</p>
                                            <h2 class="PressPage-facts-h2">2017</h2>
                                        </div></Col>
                                    <Col md={4}>
                                        <div class="PressPage-facts-item col-md-3">
                                            <img src="https://www.cryptokitties.co/icons/location.svg" alt="Location" /><p class="PressPage-facts-p">Location</p><h2 class="PressPage-facts-h2">Vancouver, BC</h2>
                                        </div></Col>
                                    <Col md={4}>
                                        <div class="PressPage-facts-item col-md-5">
                                            <img src="https://www.cryptokitties.co/icons/plant.svg" alt="Funding" />
                                            <p class="PressPage-facts-p">Funding</p>
                                            <h2 class="PressPage-facts-h2">Sustainable Revenue Model</h2>
                                            <p>Instead of an ICO.</p>
                                        </div>
                                    </Col>



                                </Row>

                            </div>
                        </div>
                    </Col>
                </Row>
            </Container>
            <Container fluid className="mt-5 pt-5" style={{
                backgroundImage: "url('https://www.cryptokitties.co/images/pattern-tile.svg')",
                backgroundColor: "rgb(249, 248, 246)",
                backgroundSize: "50rem"
            }}>
                <Row>
                    <Col md={12}>
                        <div className=" w-75 offset-2">

                            <div class="PressPage-section">
                                <h1 class="u-margin-bottom-lg text-center mt-5 pt-5 ">Product and brand assets</h1>
                                <div class="PressPage-assetWrapper"><a class="PressPage-asset" href="https://www.cryptokitties.co/downloads/logoKit.zip"><img class="PressPage-asset-img" src="https://www.cryptokitties.co/downloads/logoPreview.png" alt="Logo Kit" /><div class="PressPage-asset-footer"><span>logoKit.zip</span></div></a><a class="PressPage-asset" href="https://www.cryptokitties.co/downloads/kittiesKit.zip"><img class="PressPage-asset-img" src="https://www.cryptokitties.co/downloads/kittiesPreview.jpg" alt="Kitties Kit" /><div class="PressPage-asset-footer"><span>kittiesKit.zip</span></div></a><a class="PressPage-asset" href="https://www.cryptokitties.co/downloads/fanciesKit.zip"><img class="PressPage-asset-img" src="https://www.cryptokitties.co/downloads/fanciesPreview.jpg" alt="Fancies Kit" /><div class="PressPage-asset-footer"><span>fanciesKit.zip</span></div></a><a class="PressPage-asset" href="https://www.cryptokitties.co/downloads/bannersKit.zip"><img class="PressPage-asset-img" src="https://www.cryptokitties.co/downloads/bannersPreview.jpg" alt="Banners Kit" /><div class="PressPage-asset-footer"><span>bannerKit.zip</span></div></a><a class="PressPage-asset" href="https://www.cryptokitties.co/downloads/screenshotKit.zip"><img class="PressPage-asset-img" src="https://www.cryptokitties.co/downloads/screenshotPreview.png" alt="Screenshot Kit" /><div class="PressPage-asset-footer"><span>screenshotKit.zip</span></div></a><a class="PressPage-asset" href="https://www.cryptokitties.co/downloads/htcKit.zip"><img class="PressPage-asset-img" src="https://www.cryptokitties.co/downloads/htcPreview.jpg" alt="HTC Kit" /><div class="PressPage-asset-footer"><span>htcKit.zip</span></div></a></div></div>
                        </div>
                    </Col>
                </Row>
            </Container>
            <Container>
                <Row>
                    <Col md={12} className="text-center w-50">
                        <div class="PressPage-section"><h1 class="u-margin-bottom-md">Spelling</h1><p class="u-margin-bottom-md">When referencing us, CryptoKitties is always written as a single word, with an uppercase C and an uppercase K. Multiple cats are CryptoKitties. A single cat is a CryptoKitty.</p><img class="u-margin-top-md img-fluid " src="https://www.cryptokitties.cohttps://www.cryptokitties.co/images/spelling.svg" alt="Correct spelling" /></div>
                    </Col>
                </Row>
            </Container>
            <div class="PressPage-bg PressPage-section"><div class="Container Container--lg Container--center"><h1 class="u-margin-bottom-md">Press and Coverage</h1><div class="PressPage-cardWrapper"><a class="PressPage-card" href="http://www.bbc.com/news/technology-42237162" target="_blank" rel="noopener noreferrer"><img class="PressPage-outlet" src="https://www.cryptokitties.co/images/logoBBC.svg" alt="BBC" /><h2 class="PressPage-card-h2">CryptoKitties craze slows down transactions on Ethereum</h2><p class="PressPage-card-p">—&nbsp; BBC</p></a><a class="PressPage-card" href="https://www.bloomberg.com/news/articles/2017-12-04/cryptokitties-quickly-becomes-most-widely-used-ethereum-app" target="_blank" rel="noopener noreferrer"><img class="PressPage-outlet" src="https://www.cryptokitties.co/images/logoBloomberg.svg" alt="Olga Kharif for Bloomberg" /><h2 class="PressPage-card-h2">CryptoKitties Mania Overwhelms Ethereum Network’s Processing</h2><p class="PressPage-card-p">—&nbsp; Olga Kharif for Bloomberg</p></a><a class="PressPage-card" href="https://blogs.wsj.com/cio/2017/12/07/ethereum-network-copes-with-surge-of-activity-as-virtual-kitten-game-goes-viral/" target="_blank" rel="noopener noreferrer"><img class="PressPage-outlet" src="https://www.cryptokitties.co/images/logoWSJ.svg" alt="The Wall Street Journal" /><h2 class="PressPage-card-h2">Ethereum Network Copes With Surge of Activity as Virtual Kitten Game Goes Viral</h2><p class="PressPage-card-p">—&nbsp; The Wall Street Journal</p></a><a class="PressPage-card" href="https://www.youtube.com/watch?v=qk7gRljIKww&amp;feature=youtu.be" target="_blank" rel="noopener noreferrer"><img class="PressPage-outlet" src="https://www.cryptokitties.co/images/logoVice.svg" alt="Elle Reeve for Vice News" /><h2 class="PressPage-card-h2">This Game Combines The Internet’s Favorite Things: Cats &amp; Cryptocurrency</h2><p class="PressPage-card-p">—&nbsp; Elle Reeve for Vice News</p></a><a class="PressPage-card" href="http://fortune.com/2017/12/04/blockchain-cryptokitties-ethereum/" target="_blank" rel="noopener noreferrer"><img class="PressPage-outlet" src="https://www.cryptokitties.co/images/logoFortune.svg" alt="Joseph Hincks for Fortune" /><h2 class="PressPage-card-h2">Introducing “CryptoKitties”, the New Digital Pets Taking Ethereum by Storm</h2><p class="PressPage-card-p">—&nbsp; Joseph Hincks for Fortune</p></a><a class="PressPage-card" href="https://cointelegraph.com/news/cryptokitties-sales-hit-12-million-could-be-ethereums-killer-app-after-all" target="_blank" rel="noopener noreferrer"><img class="PressPage-outlet" src="https://www.cryptokitties.co/images/logoCointelegraph.svg" alt="Joseph Young for Cointelegraph" /><h2 class="PressPage-card-h2">CryptoKitties Sales Hit $12 Million, Could be Ethereum’s Killer App After All</h2><p class="PressPage-card-p">—&nbsp; Joseph Young for Cointelegraph</p></a><a class="PressPage-card" href="https://qz.com/1144169/the-ethereum-world-is-now-obsessed-with-breeding-cartoon-cats/" target="_blank" rel="noopener noreferrer"><img class="PressPage-outlet" src="https://www.cryptokitties.co/images/logoQuartz.svg" alt="Joon Ian Wong for Quartz" /><h2 class="PressPage-card-h2">The ethereum world is now obsessed with breeding cartoon cats</h2><p class="PressPage-card-p">—&nbsp; Joon Ian Wong for Quartz</p></a><a class="PressPage-card" href="https://motherboard.vice.com/en_us/article/bj78jv/cryptokitties-blockchain-cats-axiom-zen-game" target="_blank" rel="noopener noreferrer"><img class="PressPage-outlet" src="https://www.cryptokitties.co/images/logoMotherboard.svg" alt="Daniel Oberhaus for Motherboard" /><h2 class="PressPage-card-h2">I Bred ‘Crypto Kitties’ on the Ethereum Blockchain</h2><p class="PressPage-card-p">—&nbsp; Daniel Oberhaus for Motherboard</p></a><a class="PressPage-card" href="https://www.forbes.com/sites/ksamani/2017/10/20/what-happens-when-you-lock-400-crypto-nerds-in-a-room-for-the-weekend/#693b6bff4feb" target="_blank" rel="noopener noreferrer"><img class="PressPage-outlet" src="https://www.cryptokitties.co/images/logoForbes.svg" alt="Kyle Samani for Forbes" /><h2 class="PressPage-card-h2">What Happens When You Lock 400 Crypto Nerds In A Room For The Weekend</h2><p class="PressPage-card-p">—&nbsp; Kyle Samani for Forbes</p></a></div></div></div>
            <Container>
                <Row>
                    <Col>

                        <div class="Container Container--xs Container--center"><div class="PressPage-section"><h1 class="u-margin-bottom-lg">News and Insights</h1><a href="http://www.newswire.ca/news-releases/cryptokitties-the-worlds-first-ethereum-game-launches-today-660494073.html" class="PressPage-link" target="_blank" rel="noopener noreferrer"><span class="u-link-text">CryptoKitties: The World’s First Ethereum Game Launches</span></a><a href="https://hackernoon.com/building-a-bridge-between-blockchain-and-consumers-with-cats-104ac6655563" class="PressPage-link" target="_blank" rel="noopener noreferrer"><span class="u-link-text">Building a Bridge Between Blockchain and Consumers with Cats</span></a><a href="https://medium.com/@bennygiang/why-were-not-doing-an-initial-coin-offering-ico-5a6d6dfedca1" class="PressPage-link" target="_blank" rel="noopener noreferrer"><span class="u-link-text">Why We’re Not Doing An Initial Coin Offering (ICO)</span></a><a href="http://www.newswire.ca/news-releases/cats-invade-worlds-largest-ethereum-hackathon-651263343.html" class="PressPage-link" target="_blank" rel="noopener noreferrer"><span class="u-link-text">Cats Invade World’s Largest Ethereum Hackathon</span></a></div></div>
                    </Col>
                </Row>
            </Container>
            <Footer />
        </div >
    )
}

export default Press
