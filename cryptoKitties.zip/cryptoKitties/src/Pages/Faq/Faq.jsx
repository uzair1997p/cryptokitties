import './Faq.css'
import { Container, Row, Col } from 'react-bootstrap';
import Navbar from '../../Components/Navbar/NavBar'
import Footer from '../../Components/Footer/Footer'
import { useState } from 'react'
import { text } from 'dom-helpers';
const Faq = () => {
    const [accordin, setAccordin] = useState(false)
    console.log(accordin)
    const handleAccordin = () => {

        setAccordin(!accordin)
    }
    return (
        <div>
            <Navbar />
            <Container fluid>
                <div
                    style={{

                        backgroundSize: "50rem",
                        width: "100%",

                        backgroundRepeat: "no-repeat",
                        backgroundPosition: "center",
                        backgroundColor: "#fae1ca",
                        textAlign: "center",
                        display: "flex",
                        justifyContent: "center",
                        alignItems: "center",
                    }}
                >
                    <img src="https://www.cryptokitties.co/images/kitty-confused-banner.svg" alt="" />
                </div>
            </Container>
            <Container className="py-5">
                <div class="">
                    <div class="FaqGroup"><h2 class="FaqGroup-title">What do I need to play?</h2>
                        <div class="FaqGroup-questions">
                            <div class="Collapse Faq" role="button" id="a-computer-running-chrome-or-firefox">
                                <div role="button" class="Collapse-header d-flex justify-content-between  " >
                                    <span class="Job-title">A computer running Chrome or Firefox </span>
                                    <span onClick={handleAccordin}>+</span>




                                </div>

                                {
                                    accordin &&
                                    <div class="Collapse-body">
                                        <p><h2 id="can-i-play-on-a-mobile-device">Can I play on a mobile device?</h2>
                                            <p>You sure can!Mobile wallets like Coinbase Wallet and Trust support CryptoKitties.Plus, we’re building a mobile app for CryptoKitties, so you’ll soon be able to play everywhere!</p>
                                            <h2 id="can-i-log-in-from-multiple-computers">Can I log in from multiple computers?</h2>
                                            <p>You can use CryptoKitties from multiple computers as long as you have your digital wallet installed on both.</p>
                                            <h2 id="can-i-use-a-different-browser">Can I use a different browser?</h2>
                                            <p>We recommend sticking with Chrome or Firefox.It may be technically possible to use another browser, but we can’t guarantee optimal performance, so you may want to steer clear.</p>
                                        </p>
                                    </div>
                                }
                            </div>

                        </div>
                    </div>
                </div>
                <div class="">
                    <div class="FaqGroup"><h2 class="FaqGroup-title">What do I need to play?</h2>
                        <div class="FaqGroup-questions">
                            <div class="Collapse Faq" role="button" id="a-computer-running-chrome-or-firefox">
                                <div role="button" class="Collapse-header d-flex justify-content-between  " >
                                    <span class="Job-title">A computer running Chrome or Firefox </span>
                                    {/* <b onClick={handleAccordin}>+</b> */}




                                </div>

                                {
                                    accordin &&
                                    <div class="Collapse-body">
                                        <p><h2 id="can-i-play-on-a-mobile-device">Can I play on a mobile device?</h2>
                                            <p>You sure can!Mobile wallets like Coinbase Wallet and Trust support CryptoKitties.Plus, we’re building a mobile app for CryptoKitties, so you’ll soon be able to play everywhere!</p>
                                            <h2 id="can-i-log-in-from-multiple-computers">Can I log in from multiple computers?</h2>
                                            <p>You can use CryptoKitties from multiple computers as long as you have your digital wallet installed on both.</p>
                                            <h2 id="can-i-use-a-different-browser">Can I use a different browser?</h2>
                                            <p>We recommend sticking with Chrome or Firefox.It may be technically possible to use another browser, but we can’t guarantee optimal performance, so you may want to steer clear.</p>
                                        </p>
                                    </div>
                                }
                            </div>

                        </div>
                    </div>
                </div>


            </Container>


            <Footer />
        </div >
    )
}

export default Faq
