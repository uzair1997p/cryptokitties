import NavBar from '../../Components/Navbar/NavBar'
import { Container, Row, Col, InputGroup, FormControl, Button } from 'react-bootstrap'
const NewsLetter = () => {
    return (
        <div>
            <NavBar />
            <Container className="">
                <Row style={{ boxShadow: "0 0.6rem 1.2rem 0 hsl(36deg 7% 59% / 12%)", borderRadius: "10px", border: "0.1rem solid #e7e6e4" }}>
                    <Col md={10}>
                        <Container>

                            <Row>

                                <Col md={6} className="p-3 pl-0"  >
                                    <img src="https://images.ctfassets.net/bktrgw6io7fv/4YUuVUyjBtQpQE1zjXEF5Z/a6c96dea69291d4a966a5c7a24a3146f/marketingOpt_large.png" alt="" />
                                </Col>
                                <Col md={6} className="p-5 pl-0">
                                    <h2>
                                        Join the Breeder's Club!
                                    </h2>
                                    <p>Discover the latest Fancy recipes
                                    </p>
                                    <p>
                                        Get notified about community events!
                                    </p>
                                    <div>
                                        <InputGroup size="lg" className="mb-3">
                                            <FormControl aria-label="Large" aria-describedby="inputGroup-sizing-sm" />
                                        </InputGroup>
                                        <Button
                                            size="lg"
                                        >Subscribe</Button>
                                    </div>
                                </Col>
                            </Row>
                        </Container>
                    </Col>


                </Row>
            </Container>

        </div >
    )
}

export default NewsLetter
