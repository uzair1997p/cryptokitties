import NavBar from '../../Components/Navbar/NavBar';
import Footer from '../../Components/Footer/Footer';
import { Container, Row, Col, Button } from 'react-bootstrap';
import img from '../../assets/image.png';
import cat from '../../assets/heartCat.png';
import './homePage.css';
const HomePage = () => {
    return (
        <div>
            <NavBar />
            <div style={{
                backgroundImage: `url(${img})`,
                backgroundSize: "cover",
                width: "100%",
                height: "700px",
                backgroundRepeat: "no-repeat",
                backgroundPosition: "center"
            }} >
                <div className="display-4 font-weight-bold text-center">
                    CryptoKitties

                </div>
                <p className="display-5  font-weight-bold text-center" style={{ color: "#82817d" }}>Collect and breed furrever friends!</p>


                <Container className="bg-white  w-75  mb-5 rounded" style={{
                    marginTop: "270px", boxShadow: " 0 0.2rem 0 0 #e7e6e4, 0 0.6rem 1.5rem 0 rgb(42 40 37 / 20%)", borderRadius: "10px", zIndex: "1!important"
                }

                }>
                    <Row className="py-md-5 py-sm-1 py-xs-1 mb-5 "  >
                        <Col md={4} className="text-center mt-md-5 mt-sm-0 mt-xs-0 ">
                            <Button>
                                Get Your Own Kitty
                            </Button>
                        </Col>
                        <Col md={4}>
                            <p>

                                Buy & sell cats with our community
                            </p>
                            <p>

                                Create collections & earn rewards
                            </p>
                            <p>

                                Breed adorable cats & unlock rare traits
                            </p>

                        </Col>
                        <Col md={4} className=" pb-md-0pb-sm-3 pb-xs-3">
                            <p>Crack puzzles alongside other players</p>
                            <p>fancies
                                Chase limited edition Fancy cats</p>
                            <p className="mb-3">
                                games
                                Play games in the KittyVerse
                            </p>
                        </Col>
                    </Row>
                </Container>


            </div>
            <Container fluid
                style={{
                    backgroundImage: `url("https://www.cryptokitties.co/images/pattern-tile.svg")`,
                    backgroundSize: " 44rem auto",
                    backgroundColor: "#f3f1ee",

                }}>
                <Row className="offset-md-1 offset-sm-0  offset-xs-0 ">
                    <Col md={10} style={{ marginTop: "200px", marginBottom: "300px", }} className=" py-5 px-5  bg-white ">
                        <Row >

                            <Col md={6} className="text-center">


                                <img src="https://www.cryptokitties.co/images/kitty-eth.svg" alt="" />
                            </Col>
                            <Col md={6}>
                                <h1>
                                    What is CryptoKitties?
                                </h1>
                                <p className="h4" style={{ color: "#82817d" }}>

                                    CryptoKitties is a game centered around breedable, collectible, and oh-so-adorable creatures we call CryptoKitties! Each cat is one-of-a-kind and 100% owned by you; it cannot be replicated, taken away, or destroyed.
                                </p>
                            </Col>
                        </Row>
                    </Col>
                </Row>

            </Container>
            <Container className="mt-5">
                <Row>
                    <Col md={12} className="text-center">
                        <h1>
                            Start Your Digital Cat Collection

                        </h1>
                        <h3>
                            In CryptoKitties you can breed and adopt Kitties of all colours and shapes. Create Collections of your favourite cats and share them with our breeding community.
                        </h3>
                    </Col>

                    <Col md={3} sm={4} xs={6}>
                        <div class="CollectionCard" data-allytip="true">
                            <a data-testid="collection-navigate" href="/profile/0xd387a6e4e84a6c86bd90c158c6028a58cc8ac459/collections/16"><div class="CollectionCard-header"><div class="CollectionCard-title">Eiffel 65 - Blue</div><div class="CollectionCard-txt">10 kitties<span class="PurrBadge" role="button"><span class="PurrBadge-hearts"><span class="PurrBadge-heart"><svg width="16" height="16" viewBox="0 0 16 16"><path fill="none" fill-rule="evenodd" stroke="#C4C3C0" stroke-width="1.5" d="M8.51758033,3.23674242 L7.99492727,3.77368085 L7.45750969,3.25152048 C5.2131534,1.07088114 2.20576154,1.71726819 1.22992005,3.71000904 C0.388939117,5.4273546 0.651071091,7.49758638 1.94656752,8.85093245 L7.08023272,14.186576 C7.55888132,14.6840565 8.35019029,14.6993227 8.84767079,14.2206742 C8.86493913,14.2038443 8.86493913,14.2038443 8.88176895,14.186576 L14.021909,8.84428562 C15.3554405,7.49217551 15.639875,5.03536302 14.6802675,3.52456868 C13.4550742,1.59563937 10.6210262,1.07580436 8.51758033,3.23674242 Z"></path></svg></span><span class="PurrBadge-heartFill"><svg width="22" height="22" viewBox="0 0 22 22"><g fill="none" fill-rule="evenodd"><g transform="translate(4 5.546)"><mask id="b" fill="#fff"><path d="M5.636 11.169L1.799 6.763l-.037-.036c-1.66-1.621-1.78-4.133-.244-5.593 1.45-1.38 3.882-1.36 5.59-.015 1.705-1.345 4.139-1.363 5.587.015 1.535 1.46 1.421 3.973-.255 5.601l-.034.036-4.222 4.552c-.081.077-.964.318-1.079.317-.114.001-1.388-.394-1.47-.471z"></path></mask><path fill="#FFA6D8" d="M5.636 11.169L1.799 6.763l-.037-.036c-1.66-1.621-1.78-4.133-.244-5.593 1.45-1.38 3.882-1.36 5.59-.015 1.705-1.345 4.139-1.363 5.587.015 1.535 1.46 1.421 3.973-.255 5.601l-.034.036-4.222 4.552c-.081.077-.964.318-1.079.317-.114.001-1.388-.394-1.47-.471z"></path><path fill="#EA60AE" fill-rule="nonzero" d="M6.815 11.566L2.184 7.03C.479 5.28.25 2.554 1.827.978c1.49-1.49 4.823-1.244 4.988.36-1.292-.772-2.878.366-3.364 1.873-.429 1.33 0 3.257 3.189 7.315.316.402.973.334 1.518.128 0 .159-.448.463-1.343.912z" mask="url(#b)"></path><path fill="#FFE1F2" fill-rule="nonzero" d="M12.992 11.977L8.36 7.442c-1.705-1.75-1.933-4.476-.356-6.052C9.493-.1 12.12-1.081 13.58 1.8 11.7.294 9.561 1.584 9.123 2.968c-.437 1.384-.291 4.035 1.07 5.396.343.343 3.597 2.908 4.141 2.702 0 .159-.447.462-1.342.911z" mask="url(#b)" transform="matrix(-1 0 0 1 21.276 0)"></path></g><path stroke="#2A2825" stroke-width="1.5" d="M9.726 16.567c-1.835-1.557-3.22-2.934-4.155-4.13-1.726-2.208-1.828-4.462-.252-6.038C6.81 4.91 9.765 5.391 11 7.347c1.338-1.904 4.31-2.435 5.796-.948 1.576 1.576 1.436 4.088-.262 6.046-.928 1.071-2.323 2.435-4.185 4.092a2 2 0 0 1-2.623.03z"></path></g></svg></span></span><span class="PurrBadge-count">51</span></span></div></div><div class="CollectionCard-image CollectionCard-image--shadow CollectionCard--color-cyan"><img src="https://storage.googleapis.com/ck-kitty-image/0x06012c8cf97bead5deae237070f9587f8e7a266d/733342.svg" alt="Kitty Blue his house," /></div><div class="CollectionCard-profile"><img class="CollectionCard-profileImg" src="https://pbs.twimg.com/profile_images/1267497103015792640/QboypHHL_bigger.jpg" alt="Collector profile" /><div class="CollectionCard-ownerInfo"><div class="CollectionCard-curateText">Curated by</div><div class="CollectionCard-ownerName"><span class="DapperText">Pranksy</span></div></div></div></a>
                        </div>
                    </Col>
                    <Col md={3} sm={4} xs={6}>
                        <div class="CollectionCard" data-allytip="true">
                            <a data-testid="collection-navigate" href="/profile/0xd387a6e4e84a6c86bd90c158c6028a58cc8ac459/collections/16"><div class="CollectionCard-header"><div class="CollectionCard-title">Eiffel 65 - Blue</div><div class="CollectionCard-txt">10 kitties<span class="PurrBadge" role="button"><span class="PurrBadge-hearts"><span class="PurrBadge-heart"><svg width="16" height="16" viewBox="0 0 16 16"><path fill="none" fill-rule="evenodd" stroke="#C4C3C0" stroke-width="1.5" d="M8.51758033,3.23674242 L7.99492727,3.77368085 L7.45750969,3.25152048 C5.2131534,1.07088114 2.20576154,1.71726819 1.22992005,3.71000904 C0.388939117,5.4273546 0.651071091,7.49758638 1.94656752,8.85093245 L7.08023272,14.186576 C7.55888132,14.6840565 8.35019029,14.6993227 8.84767079,14.2206742 C8.86493913,14.2038443 8.86493913,14.2038443 8.88176895,14.186576 L14.021909,8.84428562 C15.3554405,7.49217551 15.639875,5.03536302 14.6802675,3.52456868 C13.4550742,1.59563937 10.6210262,1.07580436 8.51758033,3.23674242 Z"></path></svg></span><span class="PurrBadge-heartFill"><svg width="22" height="22" viewBox="0 0 22 22"><g fill="none" fill-rule="evenodd"><g transform="translate(4 5.546)"><mask id="b" fill="#fff"><path d="M5.636 11.169L1.799 6.763l-.037-.036c-1.66-1.621-1.78-4.133-.244-5.593 1.45-1.38 3.882-1.36 5.59-.015 1.705-1.345 4.139-1.363 5.587.015 1.535 1.46 1.421 3.973-.255 5.601l-.034.036-4.222 4.552c-.081.077-.964.318-1.079.317-.114.001-1.388-.394-1.47-.471z"></path></mask><path fill="#FFA6D8" d="M5.636 11.169L1.799 6.763l-.037-.036c-1.66-1.621-1.78-4.133-.244-5.593 1.45-1.38 3.882-1.36 5.59-.015 1.705-1.345 4.139-1.363 5.587.015 1.535 1.46 1.421 3.973-.255 5.601l-.034.036-4.222 4.552c-.081.077-.964.318-1.079.317-.114.001-1.388-.394-1.47-.471z"></path><path fill="#EA60AE" fill-rule="nonzero" d="M6.815 11.566L2.184 7.03C.479 5.28.25 2.554 1.827.978c1.49-1.49 4.823-1.244 4.988.36-1.292-.772-2.878.366-3.364 1.873-.429 1.33 0 3.257 3.189 7.315.316.402.973.334 1.518.128 0 .159-.448.463-1.343.912z" mask="url(#b)"></path><path fill="#FFE1F2" fill-rule="nonzero" d="M12.992 11.977L8.36 7.442c-1.705-1.75-1.933-4.476-.356-6.052C9.493-.1 12.12-1.081 13.58 1.8 11.7.294 9.561 1.584 9.123 2.968c-.437 1.384-.291 4.035 1.07 5.396.343.343 3.597 2.908 4.141 2.702 0 .159-.447.462-1.342.911z" mask="url(#b)" transform="matrix(-1 0 0 1 21.276 0)"></path></g><path stroke="#2A2825" stroke-width="1.5" d="M9.726 16.567c-1.835-1.557-3.22-2.934-4.155-4.13-1.726-2.208-1.828-4.462-.252-6.038C6.81 4.91 9.765 5.391 11 7.347c1.338-1.904 4.31-2.435 5.796-.948 1.576 1.576 1.436 4.088-.262 6.046-.928 1.071-2.323 2.435-4.185 4.092a2 2 0 0 1-2.623.03z"></path></g></svg></span></span><span class="PurrBadge-count">51</span></span></div></div><div class="CollectionCard-image CollectionCard-image--shadow CollectionCard--color-cyan"><img src="https://storage.googleapis.com/ck-kitty-image/0x06012c8cf97bead5deae237070f9587f8e7a266d/733342.svg" alt="Kitty Blue his house," /></div><div class="CollectionCard-profile"><img class="CollectionCard-profileImg" src="https://pbs.twimg.com/profile_images/1267497103015792640/QboypHHL_bigger.jpg" alt="Collector profile" /><div class="CollectionCard-ownerInfo"><div class="CollectionCard-curateText">Curated by</div><div class="CollectionCard-ownerName"><span class="DapperText">Pranksy</span></div></div></div></a>
                        </div>
                    </Col>
                    <Col md={3} sm={4} xs={6}>
                        <div class="CollectionCard" >
                            <a href="/profile/0xd387a6e4e84a6c86bd90c158c6028a58cc8ac459/collections/16">
                                <div class="CollectionCard-header">
                                    <div class="CollectionCard-title">Eiffel 65 - Blue</div>
                                    <div class="CollectionCard-txt">10 kitties<span class="PurrBadge" role="button"><span class="PurrBadge-hearts"><span class="PurrBadge-heart"><svg width="16" height="16" viewBox="0 0 16 16"><path fill="none" fill-rule="evenodd" stroke="#C4C3C0" stroke-width="1.5" d="M8.51758033,3.23674242 L7.99492727,3.77368085 L7.45750969,3.25152048 C5.2131534,1.07088114 2.20576154,1.71726819 1.22992005,3.71000904 C0.388939117,5.4273546 0.651071091,7.49758638 1.94656752,8.85093245 L7.08023272,14.186576 C7.55888132,14.6840565 8.35019029,14.6993227 8.84767079,14.2206742 C8.86493913,14.2038443 8.86493913,14.2038443 8.88176895,14.186576 L14.021909,8.84428562 C15.3554405,7.49217551 15.639875,5.03536302 14.6802675,3.52456868 C13.4550742,1.59563937 10.6210262,1.07580436 8.51758033,3.23674242 Z"></path></svg></span><span class="PurrBadge-heartFill"><svg width="22" height="22" viewBox="0 0 22 22"><g fill="none" fill-rule="evenodd"><g transform="translate(4 5.546)"><mask id="b" fill="#fff"><path d="M5.636 11.169L1.799 6.763l-.037-.036c-1.66-1.621-1.78-4.133-.244-5.593 1.45-1.38 3.882-1.36 5.59-.015 1.705-1.345 4.139-1.363 5.587.015 1.535 1.46 1.421 3.973-.255 5.601l-.034.036-4.222 4.552c-.081.077-.964.318-1.079.317-.114.001-1.388-.394-1.47-.471z"></path></mask><path fill="#FFA6D8" d="M5.636 11.169L1.799 6.763l-.037-.036c-1.66-1.621-1.78-4.133-.244-5.593 1.45-1.38 3.882-1.36 5.59-.015 1.705-1.345 4.139-1.363 5.587.015 1.535 1.46 1.421 3.973-.255 5.601l-.034.036-4.222 4.552c-.081.077-.964.318-1.079.317-.114.001-1.388-.394-1.47-.471z"></path><path fill="#EA60AE" fill-rule="nonzero" d="M6.815 11.566L2.184 7.03C.479 5.28.25 2.554 1.827.978c1.49-1.49 4.823-1.244 4.988.36-1.292-.772-2.878.366-3.364 1.873-.429 1.33 0 3.257 3.189 7.315.316.402.973.334 1.518.128 0 .159-.448.463-1.343.912z" mask="url(#b)"></path><path fill="#FFE1F2" fill-rule="nonzero" d="M12.992 11.977L8.36 7.442c-1.705-1.75-1.933-4.476-.356-6.052C9.493-.1 12.12-1.081 13.58 1.8 11.7.294 9.561 1.584 9.123 2.968c-.437 1.384-.291 4.035 1.07 5.396.343.343 3.597 2.908 4.141 2.702 0 .159-.447.462-1.342.911z" mask="url(#b)" transform="matrix(-1 0 0 1 21.276 0)"></path></g><path stroke="#2A2825" stroke-width="1.5" d="M9.726 16.567c-1.835-1.557-3.22-2.934-4.155-4.13-1.726-2.208-1.828-4.462-.252-6.038C6.81 4.91 9.765 5.391 11 7.347c1.338-1.904 4.31-2.435 5.796-.948 1.576 1.576 1.436 4.088-.262 6.046-.928 1.071-2.323 2.435-4.185 4.092a2 2 0 0 1-2.623.03z"></path></g></svg></span></span><span class="PurrBadge-count">51</span></span></div></div><div class="CollectionCard-image CollectionCard-image--shadow CollectionCard--color-cyan"><img src="https://storage.googleapis.com/ck-kitty-image/0x06012c8cf97bead5deae237070f9587f8e7a266d/733342.svg" alt="Kitty Blue his house," /></div><div class="CollectionCard-profile"><img class="CollectionCard-profileImg" src="https://pbs.twimg.com/profile_images/1267497103015792640/QboypHHL_bigger.jpg" alt="Collector profile" /><div class="CollectionCard-ownerInfo"><div class="CollectionCard-curateText">Curated by</div><div class="CollectionCard-ownerName"><span class="DapperText">Pranksy</span></div></div></div></a>
                        </div>
                    </Col>
                    <Col md={3} sm={4} xs={6}>
                        <div class="CollectionCard" data-allytip="true">
                            <a data-testid="collection-navigate" href="/profile/0xd387a6e4e84a6c86bd90c158c6028a58cc8ac459/collections/16"><div class="CollectionCard-header"><div class="CollectionCard-title">Eiffel 65 - Blue</div><div class="CollectionCard-txt">10 kitties<span class="PurrBadge" role="button"><span class="PurrBadge-hearts"><span class="PurrBadge-heart"><svg width="16" height="16" viewBox="0 0 16 16"><path fill="none" fill-rule="evenodd" stroke="#C4C3C0" stroke-width="1.5" d="M8.51758033,3.23674242 L7.99492727,3.77368085 L7.45750969,3.25152048 C5.2131534,1.07088114 2.20576154,1.71726819 1.22992005,3.71000904 C0.388939117,5.4273546 0.651071091,7.49758638 1.94656752,8.85093245 L7.08023272,14.186576 C7.55888132,14.6840565 8.35019029,14.6993227 8.84767079,14.2206742 C8.86493913,14.2038443 8.86493913,14.2038443 8.88176895,14.186576 L14.021909,8.84428562 C15.3554405,7.49217551 15.639875,5.03536302 14.6802675,3.52456868 C13.4550742,1.59563937 10.6210262,1.07580436 8.51758033,3.23674242 Z"></path></svg></span><span class="PurrBadge-heartFill"><svg width="22" height="22" viewBox="0 0 22 22"><g fill="none" fill-rule="evenodd"><g transform="translate(4 5.546)"><mask id="b" fill="#fff"><path d="M5.636 11.169L1.799 6.763l-.037-.036c-1.66-1.621-1.78-4.133-.244-5.593 1.45-1.38 3.882-1.36 5.59-.015 1.705-1.345 4.139-1.363 5.587.015 1.535 1.46 1.421 3.973-.255 5.601l-.034.036-4.222 4.552c-.081.077-.964.318-1.079.317-.114.001-1.388-.394-1.47-.471z"></path></mask><path fill="#FFA6D8" d="M5.636 11.169L1.799 6.763l-.037-.036c-1.66-1.621-1.78-4.133-.244-5.593 1.45-1.38 3.882-1.36 5.59-.015 1.705-1.345 4.139-1.363 5.587.015 1.535 1.46 1.421 3.973-.255 5.601l-.034.036-4.222 4.552c-.081.077-.964.318-1.079.317-.114.001-1.388-.394-1.47-.471z"></path><path fill="#EA60AE" fill-rule="nonzero" d="M6.815 11.566L2.184 7.03C.479 5.28.25 2.554 1.827.978c1.49-1.49 4.823-1.244 4.988.36-1.292-.772-2.878.366-3.364 1.873-.429 1.33 0 3.257 3.189 7.315.316.402.973.334 1.518.128 0 .159-.448.463-1.343.912z" mask="url(#b)"></path><path fill="#FFE1F2" fill-rule="nonzero" d="M12.992 11.977L8.36 7.442c-1.705-1.75-1.933-4.476-.356-6.052C9.493-.1 12.12-1.081 13.58 1.8 11.7.294 9.561 1.584 9.123 2.968c-.437 1.384-.291 4.035 1.07 5.396.343.343 3.597 2.908 4.141 2.702 0 .159-.447.462-1.342.911z" mask="url(#b)" transform="matrix(-1 0 0 1 21.276 0)"></path></g><path stroke="#2A2825" stroke-width="1.5" d="M9.726 16.567c-1.835-1.557-3.22-2.934-4.155-4.13-1.726-2.208-1.828-4.462-.252-6.038C6.81 4.91 9.765 5.391 11 7.347c1.338-1.904 4.31-2.435 5.796-.948 1.576 1.576 1.436 4.088-.262 6.046-.928 1.071-2.323 2.435-4.185 4.092a2 2 0 0 1-2.623.03z"></path></g></svg></span></span><span class="PurrBadge-count">51</span></span></div></div><div class="CollectionCard-image CollectionCard-image--shadow CollectionCard--color-cyan"><img src="https://storage.googleapis.com/ck-kitty-image/0x06012c8cf97bead5deae237070f9587f8e7a266d/733342.svg" alt="Kitty Blue his house," /></div><div class="CollectionCard-profile"><img class="CollectionCard-profileImg" src="https://pbs.twimg.com/profile_images/1267497103015792640/QboypHHL_bigger.jpg" alt="Collector profile" /><div class="CollectionCard-ownerInfo"><div class="CollectionCard-curateText">Curated by</div><div class="CollectionCard-ownerName"><span class="DapperText">Pranksy</span></div></div></div></a>
                        </div>
                    </Col>
                </Row>
            </Container>
            <Container>
                <Row>
                    <Col md={12} className="text-center my-5">
                        <h1>
                            Learn how to play CryptoKitties!
                        </h1>
                        <h4 clasName="mb-4">
                            Join our Kitten Class and learn how to get started with breeding CryptoKitties — completely free! These two Kitty cuties will join you for class, and leave when the final bell rings.
                        </h4>
                        <div clasName="mt-4 mb-5">
                            <Button size="lg" >
                                Teach  me how to  breed
                            </Button>
                        </div>
                    </Col>
                    <Col>
                        <div className="d-flex justify-content-center my-5">
                            <img src={cat} alt="" className="rounded" />
                        </div>
                    </Col>

                </Row>

            </Container>
            <Footer />
        </div >
    )
}

export default HomePage
