import loader from '../assets/loader.gif'
import { Routes, Route } from 'react-router';
// import HomePage from '../Pages/HomePage/HomePage'
// import AboutPage from '../Pages/Blog/Blog'
import { Suspense, lazy } from "react";
const HomePage = lazy(() => import('../Pages/HomePage/HomePage'));
const Blog = lazy(() => import('../Pages/Blog/Blog'));
const About = lazy(() => import('../Pages/About/About'));
const Press = lazy(() => import('../Pages/Press/Press'));
const Event = lazy(() => import('../Pages/Events/Events'));
const NewsLetter = lazy(() => import('../Pages/NewsLetter/NewsLetter'));
const KittyVerse = lazy(() => import('../Pages/KittyVerse/KittyVerse'));
const Faq = lazy(() => import('../Pages/Faq/Faq'));
const Technical = lazy(() => import('../Pages/TechnicalPage/TechnicalPage'));

const Routers = () => {
    return (
        <div>
            <Suspense fallback={<h1 style={{
                display: 'flex',
                justifyContent: 'center',
                alignItems: 'center',
                marginTop: '250px'
            }}>
                <img src={loader} alt="" />
            </h1>}>
                <Routes>

                    <Route path="/" element={<HomePage />} ></Route>
                    <Route path="blog" element={<Blog />} ></Route>
                    <Route path="about" element={<About />} ></Route>
                    <Route path="/press" element={<Press />} ></Route>
                    <Route path="/event" element={<Event />} ></Route>
                    <Route path="/news-letter" element={<NewsLetter />} ></Route>
                    <Route path="/kitty-verse" element={<KittyVerse />} ></Route>
                    <Route path="/faq" element={<Faq />} ></Route>
                    <Route path="/technical-page" element={<Technical />} ></Route>
                </Routes >
            </Suspense>
        </div >
    )
}

export default Routers
